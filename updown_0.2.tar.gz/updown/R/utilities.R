#------------------------------------------------------------------------------#
#' Model
#'
#'@param formula a formula
#'@export
#------------------------------------------------------------------------------#

model <- function(formula, data, method = 'lm', method_opts = NULL){
  method <- match.fun(method)
  args <- append(list(formula = formula, data = data), method_opts)
  m <- do.call(method, args = args)
  out <- m
}

#------------------------------------------------------------------------------#
#' Try a method
#'
#'@param method method to try
#'@export
#------------------------------------------------------------------------------#

try_method <- function(method, silent = TRUE, ...){
  attempt <- try(method(...), silent = silent)
  if(is(attempt, 'try-error')){
    data_frame(term = 'mu', estimate = NA, std.error = NA, message = attempt[[1]])
  } else {
    attempt %>% 
      mutate_(message = ~ '')
  }
}

#------------------------------------------------------------------------------#
#' Create confidence intervals for a dataset after estimates created
#'
#'@param dt a dataset
#'@export
#------------------------------------------------------------------------------#

create_conf <- function(dt, alpha){
  val <- 1 - alpha/2
  dt %>%
    mutate_(# Fay delta_1
      conf.low.1     = ~ estimate - qnorm(val) * std.error,
      conf.high.1    = ~ estimate + qnorm(val) * std.error,
      pval.1         = ~ pnorm(abs(estimate/std.error), lower.tail = FALSE),
      
      # Fay delta_2
      conf.low.2     = ~ estimate - qt(val, dH_hat) * std.error,
      conf.high.2    = ~ estimate + qt(val, dH_hat) * std.error,
      
      # Fay delta_3
      conf.low.3     = ~ estimate - qt(val, dH_tilde) * std.error,
      conf.high.3    = ~ estimate + qt(val, dH_tilde) * std.error,
      
      # Fay delta_4
      conf.low.4     = ~ estimate - qt(val, dH_hat) * std.error_bc,
      conf.high.4    = ~ estimate + qt(val, dH_hat) * std.error_bc,
      
      # Fay delta_5
      conf.low.5     = ~ estimate - qt(val, dH_tilde) * std.error_bc,
      conf.high.5    = ~ estimate + qt(val, dH_tilde) * std.error_bc,
      
      # *new* delta_7
      conf.low.7     = ~ estimate - qnorm(val) * std.error_bc,
      conf.high.7    = ~ estimate + qnorm(val) * std.error_bc,
      pval.7         = ~ pnorm(abs(estimate/std.error_bc), lower.tail = FALSE),
      
      # *new* delta_8
      conf.low.8     = ~ estimate - qt(val, df = m) * std.error_bc,
      conf.high.8    = ~ estimate + qt(val, df = m) * std.error_bc,
      pval.8         =~ pt(abs(estimate/std.error_bc), df = m, lower.tail = FALSE),
      
      # *new* delta_9
      conf.low.9     = ~ estimate - qt(val, df = m) * std.error,
      conf.high.9    = ~ estimate + qt(val, df = m) * std.error,
      pval.9         =~ pt(abs(estimate/std.error), df = m, lower.tail = FALSE))
}

#------------------------------------------------------------------------------#
#' Collect results from estimators
#'
#'@param geex_results results from geex
#'@param mu value of target parameter
#'@param L contrast matrix
#'@export
#------------------------------------------------------------------------------#

collect_results <- function(geex_results, mu, L){
  Sigma0 <- vcov(geex_results)
  Sigma_corrected0 <- get_corrections(geex_results)
  
  Sigma_mu    <- as.numeric(t(L) %*% Sigma0 %*% L )
  
  Sigma_corrected <- lapply(Sigma_corrected0, function(x){
    if(!is.null(x)) as.numeric(t(L) %*% x %*% L ) else NA
  })
  
  data_frame(term           = 'mu',
             estimate       = mu,
             std.error      = sqrt(Sigma_mu),
             std.error_bc_1 = sqrt(Sigma_corrected[[1]]),
             std.error_bc_2 = sqrt(Sigma_corrected[[2]]),
             std.error_bc_3 = sqrt(Sigma_corrected[[3]])
             # dH_hat       = dH_hat,
             # dH_tilde     = dH_tilde
  )
}