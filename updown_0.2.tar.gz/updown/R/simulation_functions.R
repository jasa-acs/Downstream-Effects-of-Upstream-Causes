#------------------------------------------------------------------------------#
#' Utility function to lookup a parameter from dataset
#'
#' @export
#------------------------------------------------------------------------------#
lookup_parameter <- function(parameters, node, s, t, variable)
{
  pm <- parameters
  pm[pm$node == node & pm$s == s & pm$t == t & pm$variable == variable, ]$value
}

#------------------------------------------------------------------------------#
#' Utility function to ap between 1 and 2 dimensions
#'
#' @export
#------------------------------------------------------------------------------#
tFUN <- function(ss, tt, nn){
  ss + (nn * tt)
}

#------------------------------------------------------------------------------#
#' Simulates dataset(s) using simcausal's simobs function
#'
#' @export
#------------------------------------------------------------------------------#
sim_data <- function(sim_obj,
                     sim_num,
                     seed = NULL,
                     n_obs,
                     sform = ~rep(rep(sim_obj$s_start:( sim_obj$SS + (sim_obj$s_start - 1 ) ), sim_obj$TT + 1), n_obs),
                     tform = ~rep(sort(rep(sim_obj$t_start:sim_obj$TT, sim_obj$SS)), n_obs) )
{
  # m = Number of independent replicates per sim; ie, # of 'years'
  simcausal::simobs(sim_obj$DAG, n = n_obs, wide = FALSE, rndseed = seed) %>%
    dplyr::mutate_(simID = ~sim_num, s = sform, t = tform )
}

#------------------------------------------------------------------------------#
#' Create a function that generates a simcausal DAG based on parameters
#'
#'@export
#------------------------------------------------------------------------------#

create_DAG <- function(Gnodes, SS = 3, s_start = 1, TT = 4, t_start = 0)
{
  D <- simcausal::DAG.empty()
  #### Build sets of nodes for the DAG ####
  function(parameters){
    DAG <- Gnodes(parameters, SS = SS, s_start = s_start, TT = TT, t_start = t_start)
    list(DAG = DAG, SS = SS, s_start = s_start, TT = TT, t_start = t_start)
  }
}

#------------------------------------------------------------------------------#
#' Create a simulator from a DAG and data.frame of parameters
#'
#' @export
#------------------------------------------------------------------------------#

create_simulator <- function(G_DAG, parameters){
  GG <- G_DAG(parameters)
  vector_length <- length(GG$s_start:GG$SS) * length(GG$t_start:GG$TT)
  
  function(nsims, m, seeds){
     out <- lapply(seq_along(m), function(i){

       sim_data(sim_obj = GG, sim_num = m[i],  n_obs = m[i]*nsims, seed = seeds[i]) %>%
        mutate_(simID = ~ as.character(rep(1:nsims, each = m[i] * vector_length) ),
                m = ~ m[i]) %>%
        
        # Create spatial lagged variables
        group_by_(~ID, ~t) %>%
        mutate_(A_slag1  = ~lag(A) ,
                L1_slag1 = ~lag(L1),
                Y_slead1 = ~lead(Y) ) %>%
        
        # Create time lagged variables
        group_by_(~ID, ~s) %>%
        mutate_(L1_tlag1 = ~lag(L1),
                A_tlag1  = ~lag(A),
                A_tlag2  = ~lag(A, 2),
                A_tlag1_slag1 = ~lag(A_slag1),
                A_tlag2_slag1 = ~lag(A_slag1, 2),
                Y_tlag1_slead1  = ~lag(Y_slead1),
                Y_tlag2_slead1  = ~lag(Y_slead1, 2) ) %>%
        ungroup()
    }  ) %>% bind_rows() %>%
      # Clean Up
      mutate_(Y_tlag1_slead1 = ~ifelse(is.na(Y_tlag1_slead1), 0, Y_tlag1_slead1),
              Y_tlag2_slead1 = ~ifelse(is.na(Y_tlag2_slead1), 0, Y_tlag2_slead1),
              A_slag1        = ~ifelse(is.na(A_slag1), 0, A_slag1),
              A_tlag1        = ~ifelse(is.na(A_tlag1), 0, A_tlag1),
              A_tlag2        = ~ifelse(is.na(A_tlag2), 0, A_tlag2),
              A_tlag1_slag1  = ~ifelse(is.na(A_tlag1_slag1), 0, A_tlag1_slag1),
              A_tlag2_slag1  = ~ifelse(is.na(A_tlag2_slag1), 0, A_tlag2_slag1))
    
    out
  }
}

#------------------------------------------------------------------------------#
#' DAG Nodes for the simulations in the up/down manuscript
#'
#' @export
#------------------------------------------------------------------------------#

DAG_nodes <- function(parameters, SS, s_start, TT, t_start){
  
  D <- simcausal::DAG.empty()
  pp <- parameters
  
  for(t in t_start:TT ){ # Per month
    for(s in s_start:SS ){ # Per location
      
      tpos  <- tFUN(s, t, SS)
      ## Initial month values ##
      if(s == 1 & t == 0){
        D <- D + node('L1',
                      distr = 'rnorm',
                      mean  = .(lookup_parameter(pp, 'L1', s, t, '(Intercept)') ),
                      sd    = .(lookup_parameter(pp, 'L1', s, t, 'mse') ),
                      t     = tpos)  +
          node('A',
               distr = 'rbern',
               prob  = plogis( .(lookup_parameter(pp, 'A', s, t, '(Intercept)') ) ),
               t     = tpos)
      }
      if(s == 2 & t == 0){
        D <- D +
          node('L2',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'L2', s, t, '(Intercept)') ),
               sd    = .(lookup_parameter(pp, 'L2', s, t, 'mse') ),
               t     = tpos) +
          node('A',
               distr = 'rbern',
               prob  = plogis( .(lookup_parameter(pp, 'A', s, t, '(Intercept)') ) ),
               t     = tpos)
      }
      if(s == 3 & t == 0){
        D <- D +
          node('Y',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'Y', s, t, '(Intercept)') ),
               sd    = .(lookup_parameter(pp, 'Y', s, t, 'mse') ),
               t     = tpos)
      }
      
      ## Later month values ##
      if(s == 1 & t > 0){
        D <- D +
          node('L1',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'L1', s, t, '(Intercept)') ) +
                 .(lookup_parameter(pp, 'L1', s, t, 'L1_tlag1') ) * L1[t - .(SS)],
               sd    = .(lookup_parameter(pp, 'L1', s, t, 'mse') ),
               t     = tpos) +
          node('A',
               distr = 'rbern',
               prob  = plogis( .(lookup_parameter(pp, 'A', s, t, '(Intercept)') ) +
                                 .(lookup_parameter(pp, 'A', s, t, 'L1') ) * L1[t] +
                                 .(lookup_parameter(pp, 'A', s, t, 'L2') ) * 0 +
                                 .(lookup_parameter(pp, 'A', s, t, 'A_slag1') ) * 0  +
                                 .(lookup_parameter(pp, 'A', s, t, 'A_tlag1') ) * A[t - .(SS)] ),
               t     = tpos)
      }
      
      if(s == 2 & t > 0){
        D <- D +
          node('L1',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'L1', s, t, '(Intercept)') ) +
                 .(lookup_parameter(pp, 'L1', s, t, 'L1_slag1') ) * L1[t - 1],
               sd    = .(lookup_parameter(pp, 'L1', s, t, 'mse') ),
               t     = tpos) +
          node('L2',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'L2', s, t, '(Intercept)') ) +
                 .(lookup_parameter(pp, 'L2', s, t, 'L1') ) * L1[t] +
                 .(lookup_parameter(pp, 'L2', s, t, 'A_slag1') ) * A[t - 1] ,
               sd    = .(lookup_parameter(pp, 'L2', s, t, 'mse') ),
               t     = tpos) +
          node('A',
               distr = 'rbern',
               prob  = plogis( .(lookup_parameter(pp, 'A', s, t, '(Intercept)') ) +
                                 .(lookup_parameter(pp, 'A', s, t, 'L1') ) * L1[t] +
                                 .(lookup_parameter(pp, 'A', s, t, 'L2') ) * L2[t] +
                                 .(lookup_parameter(pp, 'A', s, t, 'A_slag1') ) * A[t - 1]  +
                                 .(lookup_parameter(pp, 'A', s, t, 'A_tlag1') ) * A[t - .(SS)] ),
               t     = tpos)
        
      }
      if(s == 3 & t > 0){
        D <- D +
          node('Y',
               distr = 'rnorm',
               mean  = .(lookup_parameter(pp, 'Y', s, t, '(Intercept)') ) +
                 .(lookup_parameter(pp, 'Y', s, t, 'L1_slag1') ) * L1[t - 1] +
                 .(lookup_parameter(pp, 'Y', s, t, 'L2_slag1') ) * L2[t - 1] +
                 .(lookup_parameter(pp, 'Y', s, t, 'A_slag1') ) * A[t - 1] +
                 .(lookup_parameter(pp, 'Y', s, t, 'A_slag2') ) * A[t - 2] +
                 .(lookup_parameter(pp, 'Y', s, t, 'Y_tlag1') ) * Y[t - .(SS)],
               sd    = .(lookup_parameter(pp, 'Y', s, t, 'mse') ),
               t     = tpos)
        
      }
    }
  }
  
  D
}

#------------------------------------------------------------------------------#
#' Data frame of parameter values used in the up/down manuscript simulations
#'
#' @export
#------------------------------------------------------------------------------#
DAG_parameter_values <- data.frame(node = NULL,
                                   s = NULL,
                                   t = NULL,
                                   variable = NULL,
                                   value = NULL) %>%
  # L110
  bind_rows(data.frame(node = 'L1', s = 1, t = 0,
                       variable = c('(Intercept)', 'mse'), value = c(21.5, 2.5),
                       stringsAsFactors = F) ) %>%
  # L220
  bind_rows(data.frame(node = 'L2', s = 2, t = 0,
                       variable = c('(Intercept)', 'mse'), value = c(-2.8, 0.7),
                       stringsAsFactors = F) ) %>%
  # As0; s = 1, 2
  bind_rows(data.frame(node = 'A', s = c(1, 2), t = 0,
                       variable = c('(Intercept)'), value = c(log(.1/.9)),
                       stringsAsFactors = F) )  %>%
  # Y30
  bind_rows(data.frame(node = 'Y', s = 3, t = 0,
                       variable = c('(Intercept)', 'mse'), value = c(2.25, 1.25),
                       stringsAsFactors = F) ) %>%
  # L11t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'L1', s = 1, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'L1_tlag1', 'mse'),
                value = c(23, .2, 2),
                stringsAsFactors = F) ) ) %>%
  # A1t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'A', s = 1, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'L1', 'L2', 'A_slag1', 'A_tlag1'),
                value = c(-2.5, 0.09, 0.1, 0.05, 0.025),
                stringsAsFactors = F) ) ) %>%
  # L12t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'L1', s = 2, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'L1_slag1', 'mse'),
                value = c(6.75, 0.75, 1),
                stringsAsFactors = F) ) )%>%
  # L22t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'L2', s = 2, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'L1', 'A_slag1', 'mse'),
                value = c(2, -0.04, 0.3, .25),
                stringsAsFactors = F) ) )%>%
  
  # A2t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'A', s = 2, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'L1', 'L2', 'A_slag1', 'A_tlag1'),
                value = c(-2.5, 0.09, 0.1, 0.05, 0.025),
                stringsAsFactors = F) ) ) %>%
  # Y3t; t = 1, 2, 3
  bind_rows(expand.grid(node = 'Y', s = 3, t = 1:4) %>%
              merge(data.frame(
                variable = c('(Intercept)', 'A_slag1', 'A_slag2', 'L1_slag1', 'L2_slag1', 'Y_tlag1', 'mse'),
                # value = c(-5, 1.0, 0.5, 0.025, 0.05,  0.35, 1),
                value = c(-5, 1.0, 0.5, 0.025, 0.5,  0.35, 1), 
                stringsAsFactors = F) ) )

## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## 
# BEGIN data prep functions

#------------------------------------------------------------------------------#
#' Prep simulation data for gfm
#' 
#' @export
#------------------------------------------------------------------------------#

prep_simdata_gform <- function(data, group_var, Qformula, Lformula){
  data <- data %>% filter_(~ s == 2)
  Qmodel <- geepack::geeglm(formula = Y_slead1 ~ A + A_slag1 + L1 + L2 + Y_tlag1_slead1, 
                            family = gaussian, id = ID, data = data)
  Lmodel <- geepack::geeglm(formula = L2 ~ L1 + L2_tlag1 + A_slag1, 
                            family = gaussian, id = ID, data = data)
  list(data = data, Q = Qmodel, L = Lmodel)
}

#------------------------------------------------------------------------------#
#' Prep simulation data for MSM
#' 
#' @export
#------------------------------------------------------------------------------#
prep_simdata_msm <- function(data, group_var, weight_scheme){
  data <- compute_weights(data = data,
                          scheme = weight_scheme,
                          weight_names = c('W1', 'SW1'),
                          idvar = group_var,
                          extra_mutate = setNames(list(~nm, ~dn), 
                                                  c('pa.1', 'pal.1'))) %>%
    arrange(ID)
  
  ## Nontargets ##
  nuisance_models <- lapply(weight_scheme, function(x){
    thisdt <- data %>% filter_(x$filter)
    if(is.null(x$numerator)) {ff <- x$denominator } else {ff <- x$numerator}
    args <- append(x$method_opts, list(data = thisdt, formula = ff))
    m    <- do.call(x$method, args = args)
    
    list(m = m, filter = x$filter)
  })
  
  list(data = data, nm = nuisance_models)
}

#------------------------------------------------------------------------------#
#' prep simulation data for SNMs
#' 
#' @export
#------------------------------------------------------------------------------#

prep_simdata_snm <- function(Aformula,
                          Amodel_method,
                          Amodel_method_opts,
                          Y1formula,
                          Y2formula,
                          Ymodel_method,
                          Ymodel_method_opts,
                          data){
  
  Amodel <- model(formula = Aformula,
                  data        = data,
                  method      = Amodel_method,
                  method_opts = Amodel_method_opts)
  
  Y1model <- model(formula = Y1formula,
                   data        = data %>% filter(s == 2),
                   method      = Ymodel_method,
                   method_opts = Ymodel_method_opts)
  
  Y2model <- model(formula = Y2formula,
                   data        = data %>% filter(s == 2),
                   method      = Ymodel_method,
                   method_opts = Ymodel_method_opts)
  
  Ydata <- data %>%
    filter_(~ s == 2) %>%
    mutate_(f_Y2 =~ fitted(Y2model),
            f_Y1 =~ fitted(Y1model)) %>%
    select_(~ID, ~t, ~s, ~f_Y2, ~f_Y1)
  
  data <- data %>% mutate_(
    f_A = ~ fitted(Amodel),
    f_A_slag1 = ~ ifelse(s == 2, dplyr::lag(f_A), NA)) %>%
    left_join(Ydata, by = c('ID', 't', 's'))
  
  list(data = data, Amodel = Amodel, Y1model = Y1model, Y2model = Y2model)
}

#------------------------------------------------------------------------------#
#' prep simulation data for GEE
#' 
#' @export
#------------------------------------------------------------------------------#

prep_simdata_gee <- function(data, group_var, Qformula){
  data <- data %>% filter_(~ s == 2)
  Qmodel <- geepack::geeglm(formula = Y_slead1 ~ A + A_slag1 + L1 + L2 + Y_tlag1_slead1, 
                            family = gaussian, id = ID, data = data)
  list(data = data, Q = Qmodel)
}

# END data prep functions
## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## 

#------------------------------------------------------------------------------#
#' MSM weight scheme for simulations
#' 
#' @export
#------------------------------------------------------------------------------#

weight_scheme <-list( list(filter      = ~ s == 1 & t == 1,
                           numerator   = A ~ 1,
                           denominator = NULL,
                           method      = 'glm',
                           method_opts = list(family = 'binomial')),
                      list(filter      = ~ s == 1 & t > 1,
                           numerator   = A ~ A_tlag1,
                           denominator = NULL,
                           method      = 'glm',
                           method_opts = list(family = 'binomial')),
                      list(filter      = ~ s == 2 & t > 0,
                           numerator   = A ~ A_tlag1 + A_slag1,
                           denominator = NULL,
                           method      = 'glm',
                           method_opts = list(family = 'binomial')),
                      list(filter      = ~ s == 1 & t > 0,
                           numerator   = NULL,
                           denominator = A ~ L1 + A_tlag1,
                           method      = 'glm',
                           method_opts = list(family = 'binomial')),
                      list(filter      = ~ s == 2 & t > 0,
                           numerator   = NULL,
                           denominator = A ~ L1 + L2 + A_slag1 + A_tlag1,
                           method      = 'glm',
                           method_opts = list(family = 'binomial')))


#------------------------------------------------------------------------------#
#' Stamp out simulated datasets
#' 
#' @export
#------------------------------------------------------------------------------#

make_simulation <- function(){
  create_DAG(DAG_nodes) %>%
    create_simulator(DAG_parameter_values)
}

#------------------------------------------------------------------------------#
#' Do a simulation
#' 
#' @return a data.frame of simulation results
#' @export
#------------------------------------------------------------------------------#

do_simulation <- function(nsims, m, seeds, numDerivOpts, corrections = NULL,
                          parallel = FALSE, progress = 'none'){
  # Create simulated dataset(s) to analyze
  sim_data <- make_simulation()(nsims = nsims, m = m, seeds = seeds)  %>%
    # Clean up L2 variables
    group_by_(~m, ~simID, ~ID, ~t, add = FALSE) %>%
    mutate_(L2       = ~ ifelse(is.na(L2), 0, L2),
            L2_slag1 =~ dplyr::lag(L2)) %>%
    group_by_(~m, ~simID, ~ID, ~s, add = FALSE) %>%
    mutate_(L2_tlag1 = ~ dplyr::lag(L2)) %>%
    # Keep only observations necessary for estimation
    filter_(~t > 0, ~s %in% 1:2)
  
  # Analyze the data
  sim_data %>%
  {plyr::ddply(., plyr::.(m, simID), .progress = progress, .parallel = parallel,
               function(x) {
                 gfm <- try_method(estimate_gform, data = x, group_var = 'ID',
                                   prepFUN        = prep_simdata_gform, 
                                   Lvar           = 'L2',
                                   numDerivOpts   = numDerivOpts,
                                   corrections    = corrections)
                 msm <- try_method(estimate_msm, data = x, group_var = 'ID',
                                   weight_scheme  = weight_scheme,
                                   msm_formula    = Y_slead1 ~ -1 + factor(t) + A + A_slag1,
                                   prepFUN        = prep_simdata_msm,
                                   numDerivOpts   = numDerivOpts,
                                   corrections    = corrections)
                 snm <- try_method(estimate_snm_dr, data = x, group_var = 'ID',
                                   Aformula       = A ~ L1 + L2 + A_slag1 + A_tlag1,
                                   Amodel_method  = 'glm',
                                   Amodel_method_opts = list(family = binomial),
                                   Y2formula      = Y_slead1 ~ L1 + L2,
                                   Y1formula      = Y_slead1 ~ L1_slag1,
                                   Ymodel_method  = 'lm',
                                   Ymodel_method_opts = NULL,
                                   prepFUN = prep_simdata_snm,
                                   numDerivOpts   = numDerivOpts,
                                   corrections    = corrections)
                 gee <- try_method(estimate_gee, data = x, group_var = 'ID',
                                   prepFUN = prep_simdata_gee,
                                   numDerivOpts   = numDerivOpts,
                                   corrections    = corrections)
                 
                 bind_rows(gfm %>% mutate_(method = ~'gfm'),
                           msm %>% mutate_(method = ~'msm'),
                           snm %>% mutate_(method = ~'snm'),
                           gee %>% mutate_(method = ~'gee'))
               }) }
}