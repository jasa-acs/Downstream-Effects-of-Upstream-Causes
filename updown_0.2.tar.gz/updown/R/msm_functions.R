#------------------------------------------------------------------------------#
#' Compute a single probability
#'
#' @export
#------------------------------------------------------------------------------#

compute_prob <- function(method,
                         method_opts = NULL,
                         formula,
                         data,
                         density)
{

  A <- model.response(model.frame(formula, data = data))
  ## Compute fitted values ##
  if(method != 'oracle'){
    meth <- match.fun(method)

    m <-  do.call(meth, args = append(list(formula = formula,
                                           data    = data),
                                      method_opts))

    ### LAZY coding
    if(method == 'glm'){
      fits <- fitted(m)
      out <- stats::dbinom(A, 1, fits)
    } else if (method == 'lm') {
      out <- dnorm(residuals(m), sd = summary(m)$sigma)
    } else {
      stop('compute_probs is not set up for this family')
    }
  } else if(method == 'oracle'){
    if(method_opts$family == 'binomial'){
      X <- model.matrix(formula, data = data)
      fits <- plogis(X %*% method_opts$parms)
      names(fits) <- row.names(X)
      out <- stats::dbinom(A, 1, fits)
    } else if(method_opts$family == 'gaussian'){
      X <- model.matrix(formula, data = data)
      out <- stats::dnorm(A - X %*% method_opts$parms, sd = method_opts$sigma)
    }
  }
  return(out)
}

#------------------------------------------------------------------------------#
#' Compute fitted values for dataset
#'
#' @export
#------------------------------------------------------------------------------#

compute_probs <- function(scheme,
                          data,
                          pnames = c('pa', 'pal'))
{
  # scheme = list(list(filter, denominator, numerator, method, method_opts))
  dt <- data %>% mutate_(rid = ~row_number())

  inRows <- nrow(dt)

  probs <- lapply(scheme, FUN = function(x) {
    hold <- dt %>% filter_(x$filter)

    if(!is.null(x$numerator) & !is.null(x$denominator)){
      nm <-  compute_prob(formula     = x$numerator,
                          method      = x$method,
                          method_opts = x$method_opts,
                          data        = hold)
      dn <-  compute_prob(formula     = x$denominator,
                          method      = x$method,
                          method_opts = x$method_opts,
                          data        = hold)

      data.frame(rid = hold$rid, nm, dn)
    } else if(!is.null(x$numerator) & is.null(x$denominator) ) {
      nm <- compute_prob(formula     = x$numerator,
                         method      = x$method,
                         method_opts = x$method_opts,
                         data        = hold)
      data.frame(rid = hold$rid, nm)
    } else if(is.null(x$numerator) & !is.null(x$denominator) ) {
      dn <- compute_prob(formula     = x$denominator,
                         method      = x$method,
                         method_opts = x$method_opts,
                         data        = hold)
      data.frame(rid = hold$rid, dn)
    } else {
      data.frame(rid = hold$rid)
    }

  })

  probs <- Reduce(cleanerFun, probs)

  out <- full_join(dt, probs, by = 'rid') %>%
    select_(~-rid)

  outRows <- nrow(out)

  if(inRows != outRows){
    warning('Number of rows in input data.frame does not equal number of rows in output data.frame')
  }
  return(out)
}

#------------------------------------------------------------------------------#
#' Cleans up names after merging a dataset
#------------------------------------------------------------------------------#
cleanerFun <- function(x,y)
{
  z <- full_join(x, y, by = 'rid')
  if(grepl('nm.x', paste(names(z), collapse = ' ') ) ){
    z <- z %>% mutate_(nm = ~ifelse(!is.na(nm.x), nm.x, nm.y)) %>%
      select_(~-nm.x, ~-nm.y)
  }
  if(grepl('dn.x', paste(names(z), collapse = ' ') ) ){
    z <- z %>% mutate_(dn = ~ifelse(!is.na(dn.x), dn.x, dn.y)) %>%
      select_(~-dn.x, ~-dn.y)
  }

  return(z)
}


#------------------------------------------------------------------------------#
#' Take products sequentially along a matrix
#'
#' @param x a matrix
#' @return a matrix
#' @export
#------------------------------------------------------------------------------#

prod_matrix <- function(x)
{
  out <- as.matrix(x)
  for(j in 1:nrow(x)){
    for(k in 1:ncol(x)){
      out[j, k] <- prod(x[1:j, 1:k], na.rm = T)
    }
  }
  return(out)
}


#------------------------------------------------------------------------------#
#' Take products sequentially along values indexed by j and k
#'
#' @param val a vector of values
#' @param j the row variable. Must be an integer.
#' @param k the column variable. Must be an integer
#' @details Make sure that val is ordered by k then by j!
#' @return a matrix
#' @export
#------------------------------------------------------------------------------#

df_products <- function(val, j, k, matrixFUN = prod_matrix){
  matrixFUN <- match.fun(matrixFUN)

  out <- matrix(val, nrow = (max(j) - min(j) + 1), ncol = (max(k) - min(k) + 1)) %>%
    matrixFUN() %>%
    as.vector()
  return(out)
}

#------------------------------------------------------------------------------#
#' Compute W and SW across space and time
#'
#' @param data must have \code{pa} and \code{pal} variables, plus \code{timevar}
#' \code{spacevar}
#' @param spacevar character string naming space variable
#' @param timevar character string naming time variable
#' @return a dataset
#' @export
#------------------------------------------------------------------------------#

compute_weights <- function(data,
                            scheme,
                            idvar,
                            matrixFUN = prod_matrix,
                            weight_names = c('W', 'SW'),
                            extra_mutate = NULL)
{
  matrixFUN <- match.fun(matrixFUN)

  ww <- setNames(list(~1/den_prod, ~num_prod/den_prod), weight_names)

  dt <- data

  out <- dt %>% compute_probs(scheme = scheme,
                              data = .,
                              pnames = pnames ) %>%
    #  Take prod
    group_by_(idvar)

  if(!is.null(extra_mutate)){
    out <- out %>%
      mutate_(.dots = extra_mutate)
  }

  out <- out %>%
    # Arrange so that df_products creates a space (j) x time (k) matrix
    arrange_(~t, ~s) %>%
    mutate_(num_prod = ~ df_products(nm, s, t, matrixFUN),
            den_prod = ~ df_products(dn, s, t, matrixFUN) ) %>%
    mutate_(.dots = ww) %>%
    select_(~-nm, ~-dn, ~-num_prod, ~-den_prod)

  return(out)
}
