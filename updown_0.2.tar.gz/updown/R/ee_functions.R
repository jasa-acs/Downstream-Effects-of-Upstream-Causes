#------------------------------------------------------------------------------#
#' Estimating Eqns for gformula
#'
#'@export
#------------------------------------------------------------------------------#

eefun_gform <- function(data, Qmodel, Lmodel){
  QX <- model.matrix(Qmodel$formula, data = data)
  # DO NOT use model.matrix(geepackobj, data = subdata)) -
  # returns entire model matrix, not just the subset
  Y  <- model.response(model.frame(Qmodel, data = data))
  LX <- model.matrix(Lmodel$formula, data = data)
  L  <- model.response(model.frame(Lmodel, data = data))
  nY  <- length(Y)
  nL  <- length(L)

  Qp <- length(coef(Qmodel))
  Qphi <- summary(Qmodel)$geese$scale$estimate
  Lphi <- summary(Lmodel)$geese$scale$estimate

  function(theta){
    Qtheta <- theta[1:Qp]
    Ltheta <- theta[(Qp + 1): length(theta)]

    Qlp  <- QX %*% Qtheta
    Llp  <- LX %*% Ltheta

    QV <- Qphi * diag(1, nrow = nY, ncol = nY)
    LV <- Lphi * diag(1, nrow = nL, ncol = nL)
    Qgee_eqns <- (t(QX) %*% solve(QV) %*% (Y - Qlp))
    Lgee_eqns <- (t(LX) %*% solve(LV) %*% (L - Llp))
    gee_eqns  <- c(Qgee_eqns, Lgee_eqns)
    gee_eqns
  }
}

#------------------------------------------------------------------------------#
#' Estimating Eqns for MSM
#'
#'@export
#------------------------------------------------------------------------------#

eefun_msm <- function(data, formula, phi, ipmodels){

  nuisance_ees <- lapply(ipmodels, function(nm){
    thisdt <- data %>% filter_(nm$filter)
    X <- model.matrix(nm$m, data = thisdt, drop = FALSE)
    A <- model.response(model.frame(nm$m, data = thisdt))
    list(A = A, X = X, p = length(coef(nm$m)))
  })

  ## target parts ##
  dd <- data %>% filter(s == 2)

  X <- model.matrix(formula, data = dd)
  Y <- model.response(model.frame(formula, data = dd))
  n <- nrow(X)
  V <- diag(phi, nrow = n, ncol = n)
  # W <- diag(dd$SW1, nrow = n, ncol = n)
  p_msm <- ncol(X)

  function(theta){
    inc <- p_msm + 1 # targets are 1:p_msm

    nees <- list()
    weights <- list()

    xx <- lapply(1:length(nuisance_ees), function(i){
      X <- nuisance_ees[[i]]$X
      A <- nuisance_ees[[i]]$A
      p <- nuisance_ees[[i]]$p
      alpha <- theta[inc:((inc + p) - 1)]
      h <- plogis(X %*% alpha)
      w <- h^A * (1 - h)^(1 - A)
      ee <- t(X) %*% (A - h)
      inc <<- inc + p
      weights[[i]] <<- w
      nees[[i]]    <<- ee
    })

    W1 <-      ((weights[[1]][1] * weights[[3]][1]) / (weights[[4]][1] * weights[[5]][1]))
    W2 <- W1 * ((weights[[2]][1] * weights[[3]][2]) / (weights[[4]][2] * weights[[5]][2]))
    W3 <- W2 * ((weights[[2]][2] * weights[[3]][3]) / (weights[[4]][3] * weights[[5]][3]))
    W4 <- W3 * ((weights[[2]][3] * weights[[3]][4]) / (weights[[4]][4] * weights[[5]][4]))
    
    WW <- diag(c(W1, W2, W3, W4), ncol = n)
    mu <- X %*% theta[1:p_msm]
    ee <- c(
      t(X) %*% solve(V) %*% WW %*% (Y - mu),
      unlist(nees))
    ee
  }
}

#------------------------------------------------------------------------------#
#' Estimating Eqns for SNM
#'
#'@export
#------------------------------------------------------------------------------#

eefun_snm <- function(data, model){
  X <- model.matrix(model, data = data)
  Y <- model.response(model.frame(model, data = data))
  function(theta){
    p  <- length(theta)
    p1 <- length(coef(model))
    lp  <- X %*% theta[1:p1]
    rho <- plogis(lp)

    score_eqns <- apply(X, 2, function(x) sum((Y - rho) * x))
    with(data, {
      Ubeta <- (Y_slead1 - A * theta[p - 1] - A_slag1 * theta[p])
      Ubeta <- Ubeta[!is.na(Ubeta)]
      t1 <- (A[s == 2] - rho[s == 2]) * Ubeta
      t2 <- (A[s == 1] - rho[s == 1]) * Ubeta
      c(score_eqns,
        # target estimating eqns
        sum(t1),
        sum(t2))
    } )
  }
}


#------------------------------------------------------------------------------#
#' Estimating Eqns for doubly robut SNM
#'
#'@export
#------------------------------------------------------------------------------#

eefun_snm_dr <- function(data, Amodel, Ymodels){
  X <- model.matrix(Amodel, data = data)
  A <- model.response(model.frame(Amodel, data = data))
  A_ee <- list(A = A, X = X)
  
  Y_ees <- lapply(Ymodels, function(nm){
    X <- model.matrix(nm$m, data = data, drop = FALSE)
    Y <- model.response(model.frame(nm$m, data = data))
    list(Y = Y, X = X, p = length(coef(nm)))
  })
  
  function(theta){
    p  <- length(theta)
    Ap <- length(coef(Amodel))
    lp  <- X %*% theta[1:Ap]
    rho <- plogis(lp)
    Ascore_eqns <- apply(X, 2, function(x) sum((A - rho) * x))
    
    inc <- Ap + 1
    Yscore_eqns <- list()
    xx <- lapply(1:length(Y_ees), function(i){
      ee <- Y_ees[[i]]
      r  <- ee$X %*% theta[inc:(inc + ee$p - 1)]
      val <- apply(ee$X, 2, function(x) sum((ee$Y - r) * x))
      inc <<- inc + ee$p
      Yscore_eqns[[i]] <<- val
    })
    
    with(data, {

      Ubeta <- (Y_slead1 - A * theta[p - 1] - A_slag1 * theta[p])
      Ubeta <- Ubeta[!is.na(Ubeta)]
      t1 <- (A[s == 2] - rho[s == 2]) * Ubeta
      t2 <- (A[s == 1] - rho[s == 1]) * Ubeta
      c(Ascore_eqns,
        unlist(Yscore_eqns),
        # target estimating eqns
        sum(t1),
        sum(t2))
    } )
  }
}

#------------------------------------------------------------------------------#
#' Estimating Eqns for GEE
#'
#'@export
#------------------------------------------------------------------------------#

eefun_gee <- function(data, Qmodel){
  QX <- model.matrix(Qmodel$formula, data = data)
  # DO NOT use model.matrix(geepackobj, data = subdata)) -
  # returns entire model matrix, not just the subset
  Y  <- model.response(model.frame(Qmodel, data = data))
  n  <- length(Y)
  Qp <- length(coef(Qmodel))
  Qphi <- summary(Qmodel)$geese$scale$estimate

  function(theta){
    Qtheta <- theta[1:Qp]
    Qlp  <- QX %*% Qtheta

    QV <- Qphi * diag(1, nrow = n, ncol = n)
    Qgee_eqns <- (t(QX) %*% solve(QV) %*% (Y - Qlp))
    Qgee_eqns
  }
}

