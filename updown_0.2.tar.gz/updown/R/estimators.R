#------------------------------------------------------------------------------#
#' Estimate gformula
#'
#'@export
#------------------------------------------------------------------------------#

estimate_gform <- function(data, group_var, prepFUN, Lvar, 
                           numDerivOpts = list(method = 'Richardson'),
                           corrections, ...){
  mm <- prepFUN(data, ...)

  ## Point Estimates ##
  Qcoef <- coef(mm$Q)
  Lcoef <- coef(mm$L)
  beta1 <- Qcoef['A']
  beta2 <- Qcoef['A_slag1']
  beta4 <- Qcoef[Lvar]
  gamma3 <- Lcoef['A_slag1']
  mu <- beta1 + beta2 + (beta4 * gamma3)

  ## Variance Estimates ##
  theta <- c(Qcoef, Lcoef)

  Qpos <- which(names(Qcoef) %in% c('A', 'A_slag1', Lvar))
  Lpos <- which(names(Lcoef) %in% c('A_slag1'))
  LQpos <- max(Qpos) + Lpos + 1
  targetpos <- c(Qpos, LQpos)

  
  ### TRY variance estimation ###
  L <- rep(0, length(theta))
  L[targetpos] <- 1
  
  geex_results <- geex::m_estimate(
    estFUN        = eefun_gform,
    data          = data,
    units         = group_var,
    outer_args    = list(Qmodel = mm$Q, Lmodel = mm$L),
    compute_roots = FALSE,
    roots         = theta,
    deriv_control = new("deriv_control", .options = numDerivOpts),
    corrections   = corrections
  )
  
  # Apply delta method #
  h <- rep(0, length(theta))
  h[Qpos] <- c(1, 1, gamma3)
  h[LQpos] <- beta4
  
  collect_results(geex_results, mu, L = h)

}


#------------------------------------------------------------------------------#
#' Estimate MSM
#'
#'@export
#------------------------------------------------------------------------------#

estimate_msm <- function(data, group_var, weight_scheme, msm_formula, prepFUN, 
                         numDerivOpts = list(method = 'Richardson'),
                         corrections, ...){

  prep <- prepFUN(data, group_var, weight_scheme)

  
  dt <- as.data.frame(prep$data)

  ## Point Estimates ##
  geeargs <- list(data = dt,
                  weights = dt[['SW1']],
                  id = quote(ID),
                  formula = msm_formula, family = gaussian())

  mm   <- do.call(geepack::geeglm, args = geeargs)
  beta <- coef(mm)
  targetpos <-which(names(beta) %in% c('A', 'A_slag1'))
  phi  <- summary(mm)$geese$scale$estimate
  mu   <- sum(beta[targetpos])

  nuisance_coef <- lapply(prep$nm, function(x) coef(x[['m']]))

  ## Variance Estimates ##
  theta   <- c(beta, unlist(nuisance_coef)) # putting the targets first

  L <- rep(0, length(theta))
  L[targetpos] <- 1
  
  
  geex_results <- geex::m_estimate(
    estFUN        = eefun_msm,
    data          = data,
    units         = group_var,
    outer_args    = list(phi         = phi,
                         formula     = msm_formula,
                         ipmodels    = prep$nm),
    compute_roots = FALSE,
    roots         = theta,
    deriv_control = new("deriv_control", .options = numDerivOpts),
    corrections   = corrections
  )
  
  collect_results(geex_results, mu, L)
  
}

#------------------------------------------------------------------------------#
#' Estimate SNM
#'
#'@export
#------------------------------------------------------------------------------#

estimate_snm_dr <- function(data, group_var, prepFUN, 
                            numDerivOpts = list(method = 'Richardson'),
                            corrections, ...){
  mm <- prepFUN(data, ...)
  dt <- mm$data
  
  dt2 <- dt %>%
    filter_(~s == 2) %>%
    mutate_(
      B1 = ~ A_slag1 - f_A_slag1,
      B2 = ~ A - f_A,
      C  = ~ B2 * (Y_slead1 - f_Y2),
      D  = ~ B2 * A,
      E  = ~ A_slag1 * B2,
      F_ = ~ (Y_slead1 - f_Y1) * B1,
      G  = ~ A * B1,
      H  = ~ A_slag1 * B1)
  
  # sum across t
  hold <- dt2 %>%
    group_by_(group_var) %>%
    summarise_(
      C = ~ sum(C),
      D = ~ sum(D),
      E = ~ sum(E),
      F_ = ~ sum(F_),
      G = ~ sum(G),
      H = ~ sum(H) )
  
  ### Point Estimation ####
  beta <- hold %>%
    ungroup() %>%
    summarise_(
      beta1 = ~ - ((sum(E) * sum(F_)) - (sum(C) * sum(H))) / ((sum(D) * sum(H)) - (sum(E) * sum(G))),
      beta2 = ~ - ((sum(D) * sum(F_)) - (sum(C) * sum(G))) / ((sum(E) * sum(G)) - (sum(D) * sum(H))) )
  
  ### Variance Estimation ####
  ll <- length(coef(mm$Amodel)) + length(coef(mm$Y1model)) + length(coef(mm$Y2model))
  L <- c(rep(0, ll), 1, 1)
  theta   <- c(coef(mm$Amodel), coef(mm$Y1model), coef(mm$Y2model),
               beta$beta1, beta$beta2)
  mu  <- beta$beta1 + beta$beta2

  geex_results <- geex::m_estimate(
    estFUN        = eefun_snm_dr,
    data          = data,
    units         = group_var,
    outer_args    = list(Amodel     = mm$Amodel, 
                         Ymodels    = list(mm$Y1model, mm$Y2model)),
    compute_roots = FALSE,
    roots         = theta,
    deriv_control = new("deriv_control", .options = numDerivOpts),
    corrections   = corrections
  )
  
  
  collect_results(geex_results, mu, L)
  
}

#------------------------------------------------------------------------------#
#' Estimate GEE
#'
#'@export
#------------------------------------------------------------------------------#

estimate_gee <- function(data, group_var, prepFUN, 
                         numDerivOpts =  list(method = 'Richardson'), 
                         corrections, ...){
  mm <- prepFUN(data, ...)

  ## Point Estimates ##
  Qcoef <- coef(mm$Q)
  beta1 <- Qcoef['A']
  beta2 <- Qcoef['A_slag1']
  mu <- beta1 + beta2

  ## Variance Estimates ##
  theta <- Qcoef
  targetpos <- which(names(Qcoef) %in% c('A', 'A_slag1'))
  L <- rep(0, length(theta))
  L[targetpos] <- 1
  
  
  geex_results <- geex::m_estimate(
    estFUN        = eefun_gee,
    data          = data,
    units         = group_var,
    outer_args    = list(Qmodel = mm$Q),
    compute_roots = FALSE,
    roots         = theta,
    deriv_control = new("deriv_control", .options = numDerivOpts),
    corrections   = corrections
  )
  
  collect_results(geex_results, mu, L)
  
}