context("estimators")

load("inst/programs-analysis/results/cfr_analysisdt_20171130.rda")
source("inst/programs-analysis/1a_setup_analysis_schema.R")


testdt <- cfr_analysisdt$analysisdt[[8]]


numDerivOpts <- list(method = 'Richardson', method.args = list(r = 15))
corrections <- list(
  bias_.75 = correction(FUN = fay_bias_correction, b = 0.75),
  bias_.3  = correction(FUN = fay_bias_correction, b = 0.3),
  bias_.1  = correction(FUN = fay_bias_correction, b = 0.1))

test_that("gformula works", {
  test_gform <- estimate_gform(
    data          = testdt, 
    group_var     = 'ID',
    Lvar          = scheme_Aa$gfm_Lvar,
    Qformula      = scheme_Aa$Qformula,
    Lformula      = scheme_Aa$Lformula,
    prepFUN       = prep_cfr_data_gform,
    numDerivOpts  = numDerivOpts,
    corrections   = corrections)
  
  expect_is(test_gform, "data.frame")
  expect_is(test_gform$estimate, "numeric")
  
})


test_that("msm works", {
  test_msm <- estimate_msm(
    data          = testdt, 
    group_var     = 'ID',
    weight_scheme = scheme_Aa$msm_scheme,
    msm_formula   = scheme_Aa$msm_formula, 
    prepFUN       = prep_cfr_data_msm,
    numDerivOpts  = numDerivOpts,
    corrections   = corrections)
  
  expect_is(test_msm, "data.frame")
  expect_is(test_msm$estimate, "numeric")
  
})


test_that("snm works", {
  test_snm <- estimate_snm_dr(
    data          = testdt, 
    group_var     = 'ID',
    Aformula      = scheme_Aa$snm_Aformula,
    Amodel_method = scheme_Aa$snm_Amethod,
    Amodel_method_opts = scheme_Aa$snm_Amethod_opts,
    Y2formula     = scheme_Aa$snm_Y1formula,
    Y1formula     = scheme_Aa$snm_Y1formula,
    Ymodel_method = scheme_Aa$snm_Ymethod,
    Ymodel_method_opts = scheme_Aa$snm_Ymethod_opts,
    prepFUN       = prep_cfr_data_snm,
    numDerivOpts  = numDerivOpts,
    corrections   = corrections)
  
  expect_is(test_snm, "data.frame")
  expect_is(test_snm$estimate, "numeric")
  
})

test_that("gee works", {
  test_gee <- estimate_gee(
    data          = testdt, 
    group_var     = 'ID',
    Qformula     = scheme_Aa$Qformula,
    prepFUN      = prep_cfr_data_gee,
    numDerivOpts  = numDerivOpts,
    corrections   = corrections)
  
  expect_is(test_gee, "data.frame")
  expect_is(test_gee$estimate, "numeric")
  
})
