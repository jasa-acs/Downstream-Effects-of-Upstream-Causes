library(testthat)
library(geex)

test_check("updown")
