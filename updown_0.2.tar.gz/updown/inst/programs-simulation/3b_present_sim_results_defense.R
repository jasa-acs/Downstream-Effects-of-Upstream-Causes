#------------------------------------------------------------------------------#
#   TITLE: Create figure for simulation results for final presentation
#    DATE: 2017-08-28
#  AUTHOR: Bradley Saul
#   NOTES:
#------------------------------------------------------------------------------#

plot_results <- summary_simresults %>% ungroup() %>%
  mutate(distr_label = ifelse(distr == 'N', 'N(0, 1)', 't(0, 1, df == m)'),
         sigma  = factor(var_correction, 
                         levels = c('', 'bc_3', 'bc_2', 'bc_1'),
                         labels = c('hat(Sigma)', 'hat(Sigma)^bc*(b == 0.1)', 
                                    'hat(Sigma)^bc*(b == 0.3)', 'hat(Sigma)^bc*(b == 0.75)'), 
                         ordered = TRUE),
         method = ifelse(method == 'gee', 'zgee', method),
         method = factor(method, levels = c('zgee', 'snm', 'msm', 'gfm'), ordered = TRUE),
         shape  = ifelse(m == min(m), 'start', ifelse(m == max(m), 'stop', 'middle')))


labels <- plot_results %>%
  distinct(distr_label, sigma, interval_id) %>%
  mutate(x = .77, y = .17)



plot_maker <- function(.interval_id){
  dt <- plot_results %>% filter_(~interval_id == .interval_id) %>% as.data.frame()
  mlabels <- dt  %>%
    filter_(~ interval_id == .interval_id, ~ m %in% c(min(m), max(m)), ~ method == 'snm') %>%
    mutate_(label = ~ paste0('m ==', m))
  p <- ggplot(
    data = dt, 
    aes(x = coverage, y = abs(bias), color = method)) +
    
    # PLOT ELEMENTS #
    geom_rect(xmin = .89, xmax = 0.91, ymin = 0, ymax = .2, fill = 'gray95', color = 'gray95', alpha = .8) + 
    geom_rect(xmin = .5, xmax = 1, ymin = 0, ymax = .01, fill = 'gray95', color = 'gray95', alpha = .8) + 
    geom_hline(yintercept = 0, color = 'grey75') +
    geom_vline(xintercept = 0.9, color = 'grey75') +
    geom_path(aes(group = method, linetype = method), size = 1.5) +
    geom_point(aes(shape = shape, size = shape)) +
    # Label 'm = '
    geom_text(data = mlabels, aes(x = coverage, y = abs(bias) + .005, label = label), 
              parse = TRUE, vjust = 0, hjust = 0, size = 3, inherit.aes = FALSE,
              color = 'grey50') + 
    

    
    # SCALES #
    scale_color_manual(name = '',
                       values = c('snm' = "#4553c2", 
                                  'gfm' = "#338821", 
                                  'msm' = "#af1680", 
                                  'zgee' = "grey10"),
                       # values =  c("#aee39a", "#cb907b", "#8e3344", "#4b9083"),
                       labels = c('gfm' = 'GFM', 'msm' = 'MSM', 
                                  'snm' = 'SNM', 'zgee' = 'GEE'),
                       guide = guide_legend(
                         label.position = 'right',
                         override.aes = list(shape = 16, 
                                             linetype = rep("blank", 4),
                                             label    = rep("blank", 4)))) + 
    scale_size_manual(guide = FALSE, 
                      values = c(2, 3, 3)) + 
    scale_shape_manual(guide = FALSE, 
                       values = c(16, 17, 15)) + 
    scale_y_continuous(breaks = c(0, 0.01, 0.03, 0.05, 0.15), 
                       # labels = c('0.0', '0.01', '0.025', 0.05, 0.15)
                       # expand = c(.005, 0), 
                       limits = c(0, 0.2), 
                       name = "avg|Bias|") +
    scale_x_continuous(breaks = c(0.8, 0.85, 0.89, 0.90, 0.91, 0.95, 100), 
                       labels = c('80', '85', '89   ', '90', '   91', '95', '100'), 
                       # expand = c(0, 0), 
                       limits = c(.75, 1),
                       name = 'Coverage (%)') +
    scale_linetype_manual(
      name = '', 
      values = c('snm' = 'solid',
                 'gfm' = 'solid', 
                 'msm' = 'solid',
                 'zgee' = 'solid'),
      guide = FALSE
    ) +
    
    coord_cartesian(xlim = c(.75, 1), ylim = c(-.01, .2), expand = FALSE) +
    # scale_color_discrete(guide = FALSE) + 
    
    # facet_grid(sigma ~ distr_label, labeller = label_parsed) +
    annotate('text', x = .76, y = .16, label = paste0("Distribution: ", as.character(dt[1, 'distr_label'])), 
             parse = FALSE, size = 4.5, hjust = 0, color = 'grey50') + 
    annotate('text', x = .76, y = .18, label = paste0("Variance:", dt[1, 'sigma']), 
             parse = TRUE, size = 4.5, hjust = 0, color = 'grey50') + 
    # THEME # 
    theme_classic() +
    theme(strip.background = element_blank(), #element_rect(color = 'white'),
          strip.text.y     = element_text(angle = 0, hjust = 0, color = 'grey50'),
          # strip.text       = element_blank(),
          strip.text       = element_text(hjust = .5, color = 'grey50'),
          axis.text        = element_text(size = 12, colour = 'grey50'),
          axis.title       = element_text(size = 14),
          axis.title.y     = element_text(angle = 0, vjust = .9, color = 'grey50'),
          axis.title.x     = element_text(hjust = .63, color = 'grey50'),
          axis.ticks       = element_line(color = 'grey50'),
          axis.line        = element_line(color = 'grey50'),
          legend.position    = c(.9,  .9),
          legend.background  = element_rect(fill = NA),
          legend.direction   = 'vertical',
          legend.text        = element_text(size = 8, color = 'grey50'),
          panel.spacing    = unit(.25, 'lines'),
          # panel.background = element_rect(colour="black"),
          panel.grid.major.x = element_line(color = 'grey95'),
          panel.grid.major.y = element_line(color = 'grey95'))
  
  p 
}


for(i in 1:8){
  I <- paste0("I", i)
  p <- plot_maker(I)
  ggsave(p, file = paste0("inst/figures/sim_results_defense_", I, ".pdf"), 
         width = 6.5, height = 5)
}


