#------------------------------------------------------------------------------#
#   TITLE: Do simulations for m = 150
#    DATE: 2017-01-30
#  AUTHOR: Bradley Saul
#   NOTES: Check bias for large sample size. In particular, SNMM has more bias
#          than other methods for m = 30. Does this bias go away with larger 
#          samples?
#------------------------------------------------------------------------------#
library(doMC)
library(updown)
registerDoMC(4)

test_large_sample <- do_simulation(
  nsims = 1000,
  m = 150,
  seeds = 55,
  numDerivOpts = list(method = 'simple'),
  parallel = TRUE,
  corrections = list(
    bias_.75 = list(fun = fay_bias_correction, options = list(b = 0.75)),
    bias_.3  = list(fun = fay_bias_correction, options = list(b = 0.3 )),
    bias_.1  = list(fun = fay_bias_correction, options = list(b = 0.1 )))) 

summary_large_sample <- test_large_sample %>%
  left_join(data_frame(term = c('mu'), true_value = c(1.65)), by = 'term') %>%
  mutate_(bias          = ~estimate - true_value,
          rel_bias      = ~estimate/true_value)  %>%
  group_by(term, m, method) %>%
  summarise_(bias         = ~mean(bias, na.rm = TRUE))

## Results ####
# Source: local data frame [4 x 4]
# Groups: term, m [?]
# 
# term     m method         bias
# <chr> <dbl>  <chr>        <dbl>
#   1    mu   150    gee -0.151449854
# 2    mu   150    gfm -0.002715901
# 3    mu   150    msm  0.002962592
# 4    mu   150    snm -0.003653709