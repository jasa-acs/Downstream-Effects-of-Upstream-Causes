#------------------------------------------------------------------------------#
#   TITLE: Create figure for simulation results
#    DATE: 2016-08-25
#  AUTHOR: Bradley Saul
#   NOTES:
#------------------------------------------------------------------------------#

plot_results <- summary_simresults %>% ungroup() %>%
  mutate(distr_label = ifelse(distr == 'N', 'N(0, 1)', 't(0, 1, df == m)'),
         sigma  = factor(var_correction, 
                         levels = c('', 'bc_3', 'bc_2', 'bc_1'),
                         labels = c('hat(Sigma)', 'hat(Sigma)^bc*(b == 0.1)', 
                                    'hat(Sigma)^bc*(b == 0.3)', 'hat(Sigma)^bc*(b == 0.75)'), 
                         ordered = TRUE),
         method = ifelse(method == 'gee', 'zgee', method),
         method = factor(method, levels = c('zgee', 'snm', 'msm', 'gfm'), ordered = TRUE),
         shape  = ifelse(m == min(m), 'start', ifelse(m == max(m), 'stop', 'middle')))


labels <- plot_results %>%
  distinct(distr_label, sigma, interval_id) %>%
  mutate(x = .77, y = .17)

mlabels <- plot_results %>%
  filter_(~ interval_id == 'I1', ~ m %in% c(min(m), max(m)), ~ method == 'snm') %>%
  mutate_(label = ~ paste0('m ==', m))


p <- ggplot(
  plot_results, 
  aes(x = coverage, y = abs(bias), color = method)) +
  
  # PLOT ELEMENTS #
  
  geom_text(data = labels, aes(x = x, y = y, color = NULL, 
                               label = interval_id),
            color = 'grey85', size = 6) +
  geom_rect(xmin = .89, xmax = 0.91, ymin = 0, ymax = .2, fill = 'gray95', color = 'gray95', alpha = .8) + 
  geom_rect(xmin = .5, xmax = 1, ymin = 0, ymax = .01, fill = 'gray95', color = 'gray95', alpha = .8) + 
  geom_hline(yintercept = 0, color = 'grey75') +
  geom_vline(xintercept = 0.9, color = 'grey75') +
  geom_path(aes(group = method, linetype = method), size = .2) +
  geom_point(aes(shape = shape, size = shape)) +
  # Label 'm = '
  geom_text(data = mlabels, aes(x = coverage, y = abs(bias) + .005, label = label), 
            parse = TRUE, vjust = 0, hjust = 0, size = 3, inherit.aes = FALSE,
            color = 'grey50') + 
  
  # SCALES #
  scale_color_manual(name = '',
                     values = c('snm' = "#4553c2", 
                                'gfm' = "#338821", 
                                'msm' = "#af1680", 
                                'zgee' = "grey10"),
                     # values =  c("#aee39a", "#cb907b", "#8e3344", "#4b9083"),
                     labels = c('gfm' = 'GFM', 'msm' = 'MSM', 
                                'snm' = 'SNM', 'zgee' = 'GEE'),
                     guide = guide_legend(
                       label.position = 'right',
                       override.aes = list(shape = 16, 
                                           linetype = rep("blank", 4),
                                           label    = rep("blank", 4)))) + 
  scale_size_manual(guide = FALSE, 
                    values = c(0.5, 0.75, 0.75)) + 
  scale_shape_manual(guide = FALSE, 
                     values = c(16, 17, 15)) + 
  scale_y_continuous(breaks = c(0, 0.01, 0.03, 0.05, 0.15), 
                     # labels = c('0.0', '0.01', '0.025', 0.05, 0.15)
                     # expand = c(.005, 0), 
                     limits = c(0, 0.2), 
                     name = expression('|'* hat(mu) - mu *'|')) +
  scale_x_continuous(breaks = c(0.8, 0.85, 0.89, 0.90, 0.91, 0.95, 100), 
                     labels = c('80', '85', '89   ', '90', '   91', '95', '100'), 
                     # expand = c(0, 0), 
                     limits = c(.75, 1),
                     name = 'Coverage (%)') +
  scale_linetype_manual(
    name = '', 
    values = c('snm' = 'solid',
               'gfm' = 'longdash', 
               'msm' = 'dotdash',
               'zgee' = 'dotted'),
    guide = FALSE
  ) +
  
  coord_cartesian(xlim = c(.75, 1), ylim = c(-.01, .2), expand = FALSE) +
  # scale_color_discrete(guide = FALSE) + 
  
  facet_grid(sigma ~ distr_label, labeller = label_parsed) +
  
  # THEME # 
  theme_classic() +
  theme(strip.background   = element_blank(), #element_rect(color = 'white'),
        strip.text.y       = element_text(angle = 0, hjust = 0, color = 'grey50'),
        # strip.text       = element_blank(),
        strip.text         = element_text(hjust = .5, color = 'grey50'),
        axis.text          = element_text(size = 6, colour = 'grey50'),
        axis.title         = element_text(size = 8),
        axis.title.y       = element_text(angle = 0, vjust = 1, color = 'grey50'),
        axis.title.x       = element_text(hjust = .50, color = 'grey50'),
        axis.ticks         = element_line(color = 'grey50'),
        legend.position    = c(.4,  .9),
        legend.background  = element_rect(fill = NA),
        legend.direction   = 'vertical',
        legend.text        = element_text(size = 8, color = 'grey50'),
        panel.spacing      = unit(.25, 'lines'),
        panel.border       = element_rect(color = "grey45", fill = NA, size = 1), 
        panel.background   = element_rect(colour="white"),
        panel.grid.major.x = element_line(color = 'grey95'),
        panel.grid.major.y = element_line(color = 'grey95'))

p

ggsave(p, file = 'manuscripts/figures/sim_results.pdf', width = 6, height = 7)
