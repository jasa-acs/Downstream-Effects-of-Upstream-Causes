#------------------------------------------------------------------------------#
#   TITLE: Determine sample size for simulations
#    DATE: 2016-08-25
#  AUTHOR: Bradley Saul
#   NOTES: targets coverage level, which should be close to 90%
#------------------------------------------------------------------------------#

sim_power <- function(target_p, accuracy, alpha){
  (target_p * (1 - target_p) * qnorm(1 - alpha/2)^2 / accuracy^2)
}


# to second decimal accuracy for coverage of 90%, .01 level
sim_power(.9, 0.005, .01) ## chosen sample size (rounded to 24000)

# to third decimal accuracy for coverage of 90%, .01 level
sim_power(.9, 0.0005, .01)

# to third decimal accuracy for coverage of 90%, .2 level
sim_power(.9, 0.0005, .2)

