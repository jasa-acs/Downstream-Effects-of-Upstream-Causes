#------------------------------------------------------------------------------#
#   TITLE: Create simulation results for presentation
#    DATE: 2016-08-25
#  AUTHOR: Bradley Saul
#   NOTES:
#------------------------------------------------------------------------------#
library(ggplot2)
library(dplyr)
library(updown)

load('inst/programs-simulation/simresults/sim_results_2017-01-27.rda')

alpha <- .1

interval_id_fun <- function(distr, correction){
  switch(paste(distr, correction, sep = '_'),
         'N_'      = 'I1',
         'N_bc_3'  = 'I2',
         'N_bc_2'  = 'I3',
         'N_bc_1'  = 'I4',
         't_'      = 'I5',
         't_bc_3'  = 'I6',
         't_bc_2'  = 'I7',
         't_bc_1'  = 'I8')
}

interval_id_fun <- Vectorize(interval_id_fun)

critical_values <- 
  expand.grid(distr = c('N', 't'), m = unique(results$m), stringsAsFactors = FALSE) %>%
  mutate_(critical_value = ~ ifelse(distr == 'N', 
                                    qnorm(1 - alpha/2, mean = 0, sd =1),
                                    qt(1 - alpha/2, df = m)) )

all_simresults <- results %>%
  left_join(data_frame(term = c('mu'), true_value = c(1.65)), by = 'term') %>%
  mutate_(bias          = ~estimate - true_value,
          rel_bias      = ~estimate/true_value)  %>%
  tidyr::gather(var_type, std_error_val, -m, -simID, -term, -estimate, 
                -message, -method, -bias, -rel_bias, -true_value) %>%
  mutate_(var_correction = ~ substr(var_type, 11, 99)) %>%
  merge(data_frame(distr = c('N', 't')), all = TRUE) %>%
  left_join(critical_values, by = c('distr', 'm')) %>%
  # Create conf intervals
  mutate_(conf.high      = ~ estimate + critical_value * std_error_val,
          conf.low       = ~ estimate - critical_value * std_error_val,
          covered        = ~ conf.low < true_value & true_value < conf.high,
          interval_id    = ~ as.character(interval_id_fun(distr, var_correction)))

summary_simresults <- all_simresults %>%
  group_by(term, m, method, distr, var_correction, interval_id) %>%
  summarise_(bias         = ~mean(bias, na.rm = TRUE),
             rel_bias     = ~mean(rel_bias, na.rm = TRUE),
             max_bias     = ~max(bias, na.rm = TRUE),
             coverage     = ~mean(covered, na.rm = TRUE),
             ase          = ~mean(std_error_val, na.rm = TRUE),
             ese          = ~sd(estimate, na.rm = TRUE),
             ase_ese      = ~ase/ese,
             failures     = ~sum(is.na(estimate) | is.na(std_error_val))) 
