#------------------------------------------------------------------------------#
#   TITLE: Do simulations
#    DATE: 2016-08-25
#  AUTHOR: Bradley Saul
#   NOTES:
#------------------------------------------------------------------------------#
library(doMC)
library(updown)
registerDoMC(4)

sim_seeds <- c(9, 19456, 65, 322, 98730)

results <- do_simulation(
  nsims = 24000,
  m = c(seq(10, 30, by = 5)),
  seeds = sim_seeds,
  numDerivOpts = list(method = 'simple'),
  parallel = TRUE,
  corrections = list(
    bias_.75 = correction(FUN = fay_bias_correction, b = 0.75),
    bias_.3  = correction(FUN = fay_bias_correction, b = 0.3 ),
    bias_.1  = correction(FUN = fay_bias_correction, b = 0.1 )) ) 

save(results, file = paste0('programs-simulation/simresults/sim_results_', Sys.Date(), '.rda'))

