#------------------------------------------------------------------------------#
#  Title: Create plots and summaries of CFR analysis for updownstream manuscript
#   Date: 12/14/2016
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

## counts used in the supplementary text
counts <- cfrresults %>%
  filter_(~ method != 'gee') %>%
  # filter_(~ failed) %>%
  filter(interval_id == 'I1') %>% # The interval doesn't matter for point estimates, just pick one 
  group_by(A_var, distance) %>%
  summarise(failures = sum(failed),
            out_range = sum(abs(estimate) > 6, na.rm = TRUE),
            n        = n())
counts


plot_data <- cfrresults %>%
  filter_(~ method != 'gee') %>%
  filter_(~ !failed)  %>%
  ## Add labels 
  mutate_(Alabel =~ ifelse(A_var == 'nh3', 'NH[3]', toupper(A_var)),
          Alabel =~ ifelse(A_var == 'no3', 'NO[3]', Alabel),
          method =~ toupper(method),
          ## Hardcode x-axis jitter to causal methods ##
          dist_jitter   =~ ifelse(method == 'gee', distance - 1800,
                                          ifelse(method == 'MSM', distance - 600,
                                                 ifelse(method == 'SNM', distance - 1200, distance))),
          distkm_jitter =~ dist_jitter/1000) %>%
  filter(interval_id == 'I1') %>% # The interval doesn't matter for point estimates, just pick one 
  dplyr::select(-var_type, -std_error_val, -var_correction, -var_type, -distr)

point_summary <- plot_data %>%
  group_by(A_var, s1_site) %>%
  summarise(all_over = !any(estimate <= 0),
            all_under = !any(estimate >= 0))

failed_summary <- cfrresults %>%
  filter_(~ method != 'gee') %>%
  mutate_(method =~ toupper(method)) %>%
  # filter_(~ failed)  %>%
  filter(interval_id == 'I1') %>%
  group_by(A_var, method, s1_site, distance) %>%
  summarise(nfailed = sum(failed),
            n       = n(),
            pfailed = nfailed/n)


ggplot(failed_summary %>% filter(A_var == 'no3'),
       aes(x = method, y = pfailed)) +
  geom_col(position = position_dodge()) + 
  facet_grid(~s1_site)

#### Plotting attributes ####
nmethods    <- length(unique(plot_data$method))
xbreaks     <- -unique(plot_data[plot_data$method == 'GFM', 'distkm'])
xlabels     <- -round(xbreaks, 0)
# Clean up overcrowded x-axis
xlabels[xlabels == 55] <- '55  '
xlabels[xlabels == 49] <- '  49'
backgrounds <- data_frame(Alabel = c('NH[3]', 'NO[3]', 'P', 'TKN'),
                          color = c('col1', 'col2', 'col1', 'col2'))

p <- ggplot(data = plot_data %>% filter(A_var == 'no3'), 
             aes(x = -distkm_jitter, y = estimate, color = method, shape = method)) + 
  
  ## Plot Geoms ##
  # geom_rect(data = backgrounds, aes(fill = color), 
  #           xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf, alpha = .2,  linetype = 'solid',
  #           inherit.aes = FALSE) + 
  # geom_text(data = backgrounds, aes(x = -130.000, y = 4.5, label = Alabel), hjust = 0, size = 6, 
  #           color = 'gray50', parse = TRUE, inherit.aes = FALSE) + 
  # X-axis
  geom_hline(yintercept = 0, color = 'grey65', linetype = 'solid', size = .25) +
  geom_point(shape = 16, size = .75) + 
  
  ## Axis scales ##
  scale_x_continuous('River km upstream of LD1', breaks = xbreaks, labels = xlabels) + 
  scale_y_continuous(name = expression(hat(mu)), 
                     breaks = c(-3, 0, 3), 
                     minor_breaks = c(-4.5, -1.5, 1.5, 4.5)) +
  coord_cartesian(xlim = c(0, -135.000), ylim = c(-6, 6), expand = FALSE) + 
  
  ## Scales ##
  scale_shape_manual(name = '', 
                     values = c('SNM' = 18, 
                                'GFM' = 16, 
                                'MSM' = 17), guide = FALSE) + 
  scale_color_manual(name = '', 
                     values = c('SNM' = "#4553c2", 
                                'GFM' = "#338821", 
                                'MSM' = "#af1680", "#04451b"),
                     guide = guide_legend(
                       label.position = 'top',
                       override.aes = list(shape = 1,
                                           linetype = rep("blank", nmethods)))) + 
  scale_fill_manual(values = c('white', 'grey85'), guide = FALSE) + 
  scale_size_manual(name = '', values = c(.2, .75), guide = FALSE) + 
  scale_alpha_manual(name = '', values = c(1, .2), guide = FALSE) + 
  
  ## Annotations ##
  geom_text(data = data.frame(x = -132, y = 4), aes(x = x, y = y),
            hjust = 0, vjust = 0, size = 5.5, color = 'gray50',
            label = 'Effect~of~NO[3]', inherit.aes = FALSE, parse = TRUE) +
  
  # facet_grid(Alabel ~.)+ 
  theme_classic() +
  theme(
        axis.text        = element_text(size = 6),
        axis.title       = element_text(size = 8),
        axis.title.y     = element_text(angle = 0, vjust = .5, color = 'grey50'),
        axis.title.x     = element_text(hjust = 0, color = 'grey50'),
        axis.ticks       = element_line(color = 'grey50'),
        axis.line.x      = element_line(color = 'grey50'),
        axis.line.y      = element_line(color = 'grey50'),
        legend.position    = c(.1,  .1),
        legend.background  = element_rect(fill = NA),
        legend.direction   = 'horizontal',
        legend.text        = element_text(size = 8),
        # panel.margin       = element_blank(),
        panel.background   = element_blank(),
        # panel.margin       = unit(.25, 'lines'),
        # panel.background   = element_rect(colour="black"),
        # panel.grid.major.x = element_line(color = 'grey95'),
        # panel.grid.major.y = element_line(color = 'grey95'),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank())

p

ggsave(p, file = 'inst/figures/cfr_no3_estimates.pdf', width = 6, height = 3)

