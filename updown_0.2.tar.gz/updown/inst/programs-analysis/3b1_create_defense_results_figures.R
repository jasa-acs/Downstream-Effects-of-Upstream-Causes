#------------------------------------------------------------------------------#
#  Title: Create CFR analysis figure for updownstream manuscript
#   Date: 9/1/2017
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

library(grid)
library(gridExtra)
library(rgdal)
library(dplyr)
library(capefear)
library(maptools)
library(maps)
library(GISTools)
library(rgeos)
library(raster)
library(gridGraphics)



plot_dt <-   prep_data_plot(cfrresults ,
                      .scheme    = 'A',
                      # .subscheme = 'b',
                      .interval  = 'I7',
                      .A_quant   = .5,
                      .N_L3_var  = 'p',
                      .P_L3_var  = 'nh3') 


plot_results <- function(plot_data, A = 'nh3', distancekm, legend_pos = c(.12,  .83)){
  
  plot_data <- filter_(plot_data, ~A_var == A)
  plot_data_dist <- filter_(plot_data, ~distkm >= distancekm )
  #### Plotting attributes ####
  nmethods    <- length(unique(plot_data$method))
  xbreaks     <- c(-unique(plot_data[plot_data$method == 'gfm', 'distkm'])$distkm, 0)
  xlabels     <- -round(xbreaks, 0)
  # Clean up overcrowded x-axis
  xlabels[xlabels == 55] <- '55  '
  xlabels[xlabels == 49] <- '  49'
  xlabels[xlabels ==  0] <- 'LD1   '
  
  ### Information for backgrounds and facetting ###
  bg_Avar     <- unique(plot_data$A_var)
  Alabel      <- ifelse(bg_Avar == 'nh3', 'NH[3]',
                        ifelse(bg_Avar == 'no3', 'NO[3]',
                               ifelse(bg_Avar == 'p', 'P',
                                      'TKN')))
  bg_color    <- c('col1', 'col2', 'col1', 'col2')
  backgrounds <- data_frame(Alabel = Alabel,
                            color = bg_color[1:length(bg_Avar)])
  last_bg     <- backgrounds$Alabel[nrow(backgrounds)]
  
  
  #### Begin build plot ####
  p <- ggplot(plot_data, aes(x = -distkm_jitter, y = estimate, 
                             group = method, 
                             color = method, 
                             size = factor(significant))) +
    ## Plot Geoms ##
    # geom_rect(
    #   data = backgrounds, 
    #   # aes(fill = color), 
    #   fill = c('white', 'grey95', 'white', 'grey95'),
    #   xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf, alpha = .2,  
    #   linetype = 'solid',
    #   inherit.aes = FALSE) + 
    
    # geom_text(data = backgrounds, aes(x = -130.000, y = 2.5, label = Alabel), hjust = 0, size = 6, 
    #           color = 'gray50', parse = TRUE, inherit.aes = FALSE) + 
    
    # X-axis
    geom_hline(yintercept = 0, color = 'grey65', linetype = 'solid', size = .5) +

    # Connect points
    geom_line(
      data = plot_data_dist,
      aes(linetype = method), size = .2,  inherit.aes = TRUE, na.rm = TRUE) +

    # Add Confidence intervals
    geom_linerange(
      data = plot_data_dist,
        aes(ymin = conf.low, ymax = conf.high), linetype = 'solid',
                   na.rm = TRUE) +
    
    geom_point(
      data = dplyr::filter(plot_data_dist, failed == FALSE), 
      aes(shape = method,
          fill  = method),
      size        = 0.8, 
      inherit.aes = TRUE, 
      na.rm       = TRUE) +
    
    geom_point(
      data = dplyr::filter(plot_data_dist, failed == TRUE), 
      aes(shape = method),
      # shape = 5,
      fill        = 'white', 
      # alpha       = ,
      size        = 1.2, 
      inherit.aes = TRUE, 
      na.rm       = TRUE) +
    
    ## Add star for significant estimates
    geom_point(data = dplyr::filter(plot_data_dist, significant == TRUE),
               aes(y = ysignificant),
               shape = 8,
               size = 1.2, inherit.aes = TRUE, na.rm = TRUE) +

    ## Plot indicators at CIs extend further
    # geom_segment(data = dplyr::filter(plot_data, cilo_extends_past == TRUE),
    #              aes(y = -3.3, yend = -3.5, xend = -distkm_jitter),
    #              arrow = arrow(length = unit(0.1, "cm")), linetype = 'solid',
    #              inherit.aes = TRUE, na.rm = TRUE) +
    # geom_segment(data = dplyr::filter(plot_data, cihi_extends_past == TRUE),
    #              aes(y = 3.3, yend = 3.5, xend = -distkm_jitter, size = factor(significant)),
    #              arrow = arrow(length = unit(0.1, "cm")), linetype = 'solid',
    #              inherit.aes = TRUE, na.rm = TRUE) +
    
    ## Scales ##
    scale_shape_manual(name = '',
                       values = c(
                         'snm' = 23, # 18,
                         'gfm' = 21, #16,
                         'msm' = 24 #17
                       ), guide = FALSE) +
    scale_color_manual(
      name = '',
      values = c('snm' = "#4553c2",
                 'gfm' = "#338821",
                 'msm' = "#af1680",
                 "#04451b"),
      labels = c('GFM', 'MSM', 'SNM')
    ) +
    scale_fill_manual(
      name = '',
      values = c('snm' = "#4553c2",
                 'gfm' = "#338821",
                 'msm' = "#af1680",
                 "#04451b"),
      guide = FALSE
    ) +
    # scale_fill_manual(values = c('white', 'grey95'), guide = FALSE) +
    scale_size_manual(name = '', values = c(.15, .55), guide = FALSE) +
    scale_alpha_manual(name = '', values = c(1, .2), guide = FALSE) +
    scale_linetype_manual(
      name = '',
      values = c('snm' = 'solid',
                 'gfm' = 'longdash',
                 'msm' = 'dotdash')
    ) +
    guides(
      color = guide_legend(
        order = 1,
        label.position = 'top',
        override.aes = list(shape = c(16, 17, 18),
                            size = 1.4,
                            linetype = rep("blank", nmethods))
      ),
      linetype = guide_legend(
        order = 2,
        title = NULL,
        label = FALSE,
        label.position = 'bottom',
        legend.theme = element_blank(),
        override.aes = list(alpha = 1,
                            size  = .65,
                            color  = c('gfm' = "#338821",
                                       'msm' = "#af1680",
                                       'snm' = "#4553c2")
        )
      )) +

    ## Axis scales ##
    scale_x_continuous('', breaks = xbreaks, labels = xlabels) + 
    scale_y_continuous(name = expression(hat(mu)), 
                       breaks = c(-2, 0, 2), 
                       minor_breaks = c(-3, -1, 1, 3)) +
    coord_cartesian(xlim = c(0, -135.000), ylim = c(-3.5, 3.5), expand = FALSE) + 
    # facet_grid(Alabel ~ ., labeller = label_parsed) + 
    
    ## Annotations ##
    geom_text(data = data.frame(x = -132, y = -3.4, Alabel = last_bg), aes(x = x, y = y),
              hjust = 0, vjust = 0, size = 3, color = 'gray50',
              label = 'River km upstream of LD1', inherit.aes = FALSE) +

    ## Theme Modifications ##
    theme_classic() +
    theme(axis.text.x  = element_text(size = 8, color = 'grey50'),
          axis.title.x = element_text(vjust = 0, hjust = 1, size = 8),
          axis.line.x  = element_line(color = 'grey50'),
          axis.text.y  = element_text(size = 8, color = 'grey50'),
          axis.title.y = element_text(angle = 0, vjust = .5, color = 'grey50'),
          axis.line.y  = element_line(color = 'grey50'),
          axis.ticks   = element_line(color = 'grey50', size = .1),
          legend.position    = legend_pos,
          legend.background  = element_rect(fill = NA),
          legend.direction   = 'horizontal',
          legend.text        = element_text(size = 8, color = 'grey50'),
          legend.margin      = margin(0, 0, 0, 0, 'lines'),
          legend.key.width   = unit(2, 'lines'),
          legend.key.height  = unit(.1, 'lines'),
          panel.grid.major.x = element_blank(),
          # panel.grid.major.x = element_line(color = "grey75", size = 0.15),
          panel.grid.minor.x = element_blank(),
          panel.grid.major.y = element_line(colour= "grey70", size=0.15),
          panel.grid.minor.y = element_line(colour= "grey80", size=0.05),
          strip.background   = element_rect(color = 'white'),
          strip.text         = element_blank())

  p
}




#------------------------------------------------------------------------------#
# Map for manuscript plot ####
#------------------------------------------------------------------------------#

### Manuscript Plot ####
# Hydro and trans data downloaded from: https://gdg.sc.egov.usda.gov

# rivers <- readOGR(dsn = "map_data/ncrivers", layer = "ncrivers")
towns  <- readOGR(dsn = "inst/extdata/map_data/twnshps",  layer = "twnshps")
hydro  <- readOGR(dsn = "inst/extdata/map_data/hydrography_NHD24K_extract_3297128_02",  
                  layer = "nhd24kst_l_extract")
trans  <- readOGR(dsn = "inst/extdata/map_data/transportation_TGRROAD_extract_3297128_03",  
                  layer = "road100k_primary_l_extract")
place <- readOGR(dsn = "inst/extdata/map_data/tl_2016_37_place",  
                 layer = "tl_2016_37_place")
urban <- readOGR(dsn = "inst/extdata/map_data/tl_2016_us_uac10",  
                 layer = "tl_2016_us_uac10")

# rivers <- spTransform(rivers, CRS("+init=epsg:4326"))
towns  <- spTransform(towns, CRS("+init=epsg:4326"))
hydro  <- spTransform(hydro, CRS("+init=epsg:4326"))
urban  <- spTransform(urban, CRS("+init=epsg:4326"))
place  <- spTransform(place, CRS("+init=epsg:4326"))

# head(rivers@data)
# head(towns@data)
# head(hydro@data)
# head(place@data)

pre_hoffer <- filter(sites, cormp_id == 'B7480000')
Hoffer <- filter(sites, cormp_id == 'B7500000')
LD1    <- filter(sites, cormp_id == 'B8349000')
cfr_sites <- filter(sites, cormp_id %in% 
                      c(union(unique(cfr_results$s1_site), unique(cfr_results$s2_site)), 'B8349000') )
cfr_sites <- SpatialPointsDataFrame(coords = as.matrix(cfr_sites[, c('long', 'lat')]),
                                    data = cfr_sites, proj4string = CRS("+init=epsg:4326"))
cfr_bbox <- matrix(c(pre_hoffer$long - .1, LD1$lat - .2, 
                     LD1$long + .1, pre_hoffer$lat + .1), nrow = 2,  
                   byrow = FALSE, dimnames = list( c('x', 'y'), c('min', 'max')))

# Clip places to area with cfr_bbox
place_wi_bounds <- crop(place, cfr_bbox)

# Create rectangular area for plotting
bnds <- cbind(x=c(pre_hoffer$long + .12, LD1$long + .12, LD1$long - .12, pre_hoffer$long - .12), 
              y=c(pre_hoffer$lat  + .12, LD1$lat  + .12,  LD1$lat - .12, pre_hoffer$lat  - .12))
plot_poly <- SpatialPolygons(list(Polygons(list(Polygon(bnds)),"bbox")), proj4string=CRS("+init=epsg:4326")  )

## Rotate objects to plot
rotateProj = function(spobj, angle) {
  # get bounding box as spatial points object
  boxpts = SpatialPoints(t(bbox(spobj)), proj4string = CRS(proj4string(spobj)))
  # convert to lat-long
  boxLL = bbox(spTransform(boxpts, CRS("+init=epsg:4326")))
  # find the centre
  llc = apply(boxLL, 1, mean)
  # construct the proj4 string
  prj = paste0("+proj=omerc +lat_0=", llc[2], " +lonc=", llc[1], " +alpha=", 
               angle, " +gamma=0.0 +k=1.000000 +x_0=0.000 +y_0=0.000 +ellps=WGS84 +units=m ")
  # return as a CRS:
  CRS(prj)
}

# get the proj4 string
plot_Proj <- rotateProj(place_wi_bounds, 55)
# transform
place_wi_bounds_r <- spTransform(place_wi_bounds, plot_Proj)
plot_poly_r       <- spTransform(plot_poly, plot_Proj)

# Create objects to plot

cfr_places  <- gIntersection(place_wi_bounds_r, plot_poly_r)
hydro_r     <- spTransform(hydro, plot_Proj)
cfr_sites_r <- spTransform(cfr_sites, plot_Proj)

cfr_sites_r <- as.data.frame(cfr_sites_r)
cfr_sites_r$distkm <- round(cfr_sites_r$distance/1000)
cfr_sites_r$text_labels <- c('', '', 'LD3', '', '', '', '',  '', 'LD2', '', '', '')


small_map <- function(highlight_distances){
    par(mai = c(0, 0, 0, 0), oma = c(0, 0, 0, 0))
    # plot(x = 0, y = 0, xlim = c(-40000, 40000), ylim = c(-1000, 4100), asp = )
    plot(x = bbox(cfr_places)[1, ], y = bbox(cfr_places)[2, ], type = 'n', lty = 0, axes = FALSE)
    lines(hydro_r[grepl('Cape Fear River', hydro_r$GNIS_NAME), ], col = '#1f78b4', lwd = 2)
    picker <- (cfr_sites_r$distance %in% highlight_distances)
    print(picker)
    
    # Add  locations
    points(x = cfr_sites_r$long.1[picker], y = cfr_sites_r$lat.1[picker] + 1000, col = 'red', bg = 'red', pch = 25)
    points(x = cfr_sites_r$long.1[!picker], y = cfr_sites_r$lat.1[!picker] + 1000, col = 'grey50', pch = 6)
    text(cfr_sites_r$distkm[1:11], x = cfr_sites_r$long.1[1:11], y = cfr_sites_r$lat.1[1:11] + 2000, cex = .65, col = 'grey50')
    # points(x = cfr_sites_r$long.1[11], y = cfr_sites_r$lat.1[11], col = 'red', pch = 20, cex = 2)
    rect(xleft   = cfr_sites_r$long.1[12] - 100, 
         ybottom = cfr_sites_r$lat.1[12]  - 500, 
         xright  = cfr_sites_r$long.1[12] + 100, 
         ytop    = cfr_sites_r$lat.1[12]  + 500, 
         col  = 'red',
         border  = 'red')
    text(cfr_sites_r$text_labels, 
         x = cfr_sites_r$long.1[1:12], 
         y = cfr_sites_r$lat.1[1:12] + 3000, 
         cex = .85,
         col = 'grey50')
    
    
    # Add legend
    # points(x = 19000, y = -3450, col = 'red', pch = 6)
    # text(' - sampling location', x = 26000, y = -3500, cex = .5)
    points(x = 32000, y = -12000, col = 'red', pch = 6)
    text(' - sampling location', x = 38000, y = -12000, cex = .5)
    
    # text('Fayetteville', x = -57000, y = -1000, cex = .75)
    # arrows(x0 = -63000, y0 = -1000, x1 = -64000, y1 = -1000, length = .05)
    text('Fayetteville', x = -42000, y = -9000, cex = .75)
    arrows(x0 = -47000, y0 = -9000, x1 = -48000, y1 = -9000, length = .05)
    
    # text('Wilmington', x = 19000, y = -1000, cex = .75)
    # arrows(x0 = 25000, y0 = -1000, x1 = 26000, y1 = -1000, length = .05)
    text('Wilmington', x = 38000, y = -9000, cex = .75)
    arrows(x0 = 43000, y0 = -9000, x1 = 44000, y1 = -9000, length = .05)
    
    text('N', x = 27000, y = -12000, cex = .75, srt = 55)
    # arrows(x0 = -30000, y0 = 2200, x1 = -31000, y1 = 2650, length = .05)
    arrows(x0 = 26000, y0 = -11550, x1 = 25000, y1 = -11100, length = .05)
    text('The Middle Cape Fear River', x = 32000, y = -14000, cex = .75)
}

small_map(cfr_sites_r$distance[1:2])
#------------------------------------------------------------------------------#
# Manuscript plot ####
#------------------------------------------------------------------------------#

make_plot <- function(i, A){
  i <- i + 1
  d <- cfr_sites_r$distance[i]/1000
  p <- plot_results(plot_dt, A = A, distancekm = d,  legend_pos = c(.1, .15))
  x <- function() small_map(cfr_sites_r$distance[(i - 1):i])
  
  
  pdf(file = paste0('inst/figures/cfr_results_', A, '_', i - 1, '.pdf'), width = 6.5, height = 5)
  # Make figure areas
  topVp <- viewport(name = 'base', width  = unit(6.5, 'inches' ), height = unit(5, 'inches' ))
  
  main <- viewport(y = 1, name = 'main', width  = unit(6.5, 'inches' ), height = unit(3, 'inches' ),
                   just = 'top', clip = 'off')
  
  map <- viewport(x = .52, y = 0.0, name = 'map', width  = unit(6.5, 'inches' ), height = unit(3.5, 'inches' ),
                  just = 'bottom', clip = 'off')
  
  splot <- vpTree(topVp, vpList(main, map))
  pushViewport(splot)
  ## Print analysis graphics
  seekViewport('main')
  print(p, newpage = FALSE)
  
  seekViewport('map')
  # grid.rect(gp=gpar(lty="dashed"))
  grid.echo(x, newpage = FALSE)
  dev.off()
  
}


for(j in 1:10){
  make_plot(j, A = 'no3')
}

for(j in 1:10){
  make_plot(j, A = 'nh3')
}
  



