#------------------------------------------------------------------------------#
#   Title: Run CFR analysis for updownstream manuscript
#    Date: 11/22/2016
#  Author: Bradley Saul
# Purpose: Computes models based on schema defines in 1a.
#------------------------------------------------------------------------------#
source('inst/programs-analysis/0b_prepare_analysis_data.R')
source('inst/programs-analysis/1a_setup_analysis_schema.R')

sys_date <- format(Sys.Date(), "%Y%m%d")

## Function to analyze the CFR data ####
analyze_cfr <- function(data,
                        Qformula, # outcome model for GEE and GFM,
                        Lformula, # space varying covariate model for GFM,
                        gfm_Lvar,
                        msm_formula,
                        msm_scheme,
                        snm_Aformula,
                        snm_Amethod,
                        snm_Amethod_opts,
                        snm_Y1formula,
                        snm_Y2formula,
                        snm_Ymethod,
                        snm_Ymethod_opts,
                        numDerivOpts,
                        corrections) {
  gfm <- try_method(estimate_gform, data = data, 
                    group_var     = 'ID',
                    Lvar          = gfm_Lvar,
                    Qformula      = Qformula,
                    Lformula      = Lformula,
                    prepFUN       = prep_cfr_data_gform,
                    numDerivOpts  = numDerivOpts,
                    corrections   = corrections)
  msm <- try_method(estimate_msm, data = data, 
                    group_var     = 'ID',
                    weight_schem  = msm_scheme,
                    msm_formula   = msm_formula,
                    prepFUN       = prep_cfr_data_msm,
                    numDerivOpts  = numDerivOpts,
                    corrections   = corrections)
  snm <- try_method(estimate_snm_dr, data = data, 
                    group_var     = 'ID',
                    Aformula      = snm_Aformula,
                    Amodel_method = snm_Amethod,
                    Amodel_method_opts = snm_Amethod_opts,
                    Y2formula     = snm_Y1formula,
                    Y1formula     = snm_Y1formula,
                    Ymodel_method = snm_Ymethod,
                    Ymodel_method_opts = snm_Ymethod_opts,
                    prepFUN       = prep_cfr_data_snm,
                    numDerivOpts  = numDerivOpts,
                    corrections   = corrections)
  gee <- try_method(estimate_gee, data = data, 
                    group_var    = 'ID',
                    Qformula     = Qformula,
                    prepFUN = prep_cfr_data_gee,
                    numDerivOpts = numDerivOpts,
                    corrections  = corrections)
  
  bind_rows(gfm %>% mutate(method = 'gfm'),
            msm %>% mutate(method = 'msm'),
            snm %>% mutate(method = 'snm'),
            gee %>% mutate(method = 'gee'))
}




#------------------------------------------------------------------------------#
## Analyze the CFR data ####
#------------------------------------------------------------------------------#
### TESTING ###
# test <- cfr_analysisdt %>% ungroup() %>%
#   filter(row_number() == 1) %>%
#   rowwise() %>%
#   mutate_(results_Ga = ~list(do.call(analyze_cfr,
#                                     args = append(list(data = analysisdt), analysis_Ga))))
# test$results_Ga

scheme_names <- ls()[grepl('^scheme_[A-Z]', ls())]
schemes <- mget(scheme_names)
analysis_schemes <- data_frame(scheme_name = scheme_names, schema = schemes)

options(warn = 2) # want warnings to be errors (e.g. model fails to converge)
cfr_results <- cfr_analysisdt %>% 
  filter(A_quantile > 0) %>% # A_quantile == -1 was used for treating A as continuous in testing
  merge(analysis_schemes, all = TRUE) %>%  
  rowwise() %>%
  mutate_(results = ~ list(do.call(analyze_cfr, 
                                   args = append(list(data = analysisdt), schema))))


lapply(cfr_analysisdt_complex_impute, function(x){
  x %>%   
    filter(A_quantile > 0) %>% # A_quantile == -1 was used for treating A as continuous in testing
    merge(analysis_schemes, all = TRUE) %>%  
    rowwise() %>%
    mutate_(results = ~ list(do.call(analyze_cfr, 
                                     args = append(list(data = analysisdt), schema))))
}) -> cfr_results_complex_impute



options(warn = 1)

save(cfr_results, file = paste0("inst/programs-analysis/results/", sys_date, "_cfr_results.rda"))
save(cfr_results_complex_impute, file = paste0("inst/programs-analysis/results/", sys_date, "_cfr_results_complete_impute.rda"))
