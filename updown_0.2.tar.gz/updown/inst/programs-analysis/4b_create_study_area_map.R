#------------------------------------------------------------------------------#
#  Title: Create map of NC/CFR highlight area of study
#   Date: 1/4/2017
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

library(dplyr)
library(rgdal)
library(capefear)

# Map data downloaded from: https://gdg.sc.egov.usda.gov

water_features_l <- readOGR(dsn = "inst/extdata/map_data/hydrography_NHD24K_extract_3363657_01",  
                     layer = "nhd24kst_l_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

water_features_a <- readOGR(dsn = "inst/extdata/map_data/hydrography_NHD24K_extract_3363657_01",  
                          layer = "nhd24kwb_a_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

water_features_p <- readOGR(dsn = "inst/extdata/map_data/hydrography_NHD24K_extract_3363657_01",  
                            layer = "nhd24kpe_p_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

watershed <- readOGR(dsn = "inst/extdata/map_data/hydrologic_units_WBDHU8_extract_3364500_02",  
                      layer = "wbdhu8_a_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

NC <- readOGR(dsn = "inst/extdata/map_data/government_units_NRCSTATE_nc_3363589_01",  
              layer = "state_nrcs_a_nc") %>%
  spTransform(CRS("+init=epsg:4326"))

towns <- readOGR(dsn = "inst/extdata/map_data/geographic_names_GNISPOP_extract_3364500_01",  
                 layer = "gnispop_p_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

### Update data and grab necessary pieces ####

cf_watershed <- rgeos::gIntersection(rgeos::gUnaryUnion(watershed[grepl('0303000[2-7]', watershed$HUC8), ]), NC)
cf_rivers <- rgeos::gIntersection(water_features_l[grepl('Cape Fear River|Haw River|Deep River', water_features_l$GNIS_NAME), ], cf_watershed)
black_river <- water_features_l[water_features_l$GNIS_NAME == 'Black River' & grepl('^00981539', water_features_l$GNIS_ID), ]
cf_jordan  <- rgeos::gIntersection(water_features_a[grepl('B Everett Jordan Lake', water_features_a$GNIS_NAME), ], cf_watershed)
cf_cities <- towns[grepl('Wilmington$|^Fayetteville$|Greensboro|Chapel Hill|Elizabethtown', towns$NAME), ]


cfr_sites <- filter(sites, cormp_id %in% 
                      c(unique(c(cfr_results$s1_site, cfr_results$s2_site)), 'B8349000') )
cfr_sites <- SpatialPointsDataFrame(coords = as.matrix(cfr_sites[, c('long', 'lat')]),
                                    data = cfr_sites, proj4string = CRS("+init=epsg:4326"))
cfr_sites$distkm <- round(cfr_sites$distance/1000)
cfr_sites$text_labels <- c('', '', 'LD3', '', '', '', '',  '', 'LD2', '', '', 'LD1')
site_first <- cfr_sites[1, ]
site_last  <- cfr_sites[nrow(cfr_sites), ]

# Create rectangular area for plotting

## Plotting Settings ####

water_col <- '#1f78b4'
watershed_col <- '#edf8b1'


## Level 1 ###

pdf('./figures/main_map_level1.pdf', width = 8.5, height = 4)
plot(NC, col = 'grey90', border = 'grey80')
plot(cf_watershed, col = watershed_col, add = TRUE,lwd = 0.01, border = '#addd8e')

# Plot water features
lines(cf_rivers, col = water_col, lwd = .5)
lines(black_river, col = water_col, lwd = .5)
plot(cf_jordan, add = TRUE,  col = water_col, border = water_col, lwd = .1)
plot(focus_poly, add=TRUE, border = 'red')
# Plot Major cities 

points(cf_cities, cex = .45, pch = 16)
text(x = cf_cities$LONGITUDE[1]-.375,  y = cf_cities$LATITUDE[1]+.01, cf_cities$NAME[1], cex = .5)
text(x = cf_cities$LONGITUDE[2]-.35,   y = cf_cities$LATITUDE[2],     cf_cities$NAME[2], cex = .35)
text(x = cf_cities$LONGITUDE[3],      y = cf_cities$LATITUDE[3]+.05,     cf_cities$NAME[3], cex = .35)
text(x = cf_cities$LONGITUDE[4],      y = cf_cities$LATITUDE[4]+.05, cf_cities$NAME[4], cex = .5)
text(x = cf_cities$LONGITUDE[5]+.4,  y = cf_cities$LATITUDE[5], cf_cities$NAME[5],     cex = .5)

dev.off()


## Level 2 ##
## Rotate objects to plot
rotateProj = function(spobj, angle) {
  # get bounding box as spatial points object
  boxpts = SpatialPoints(t(bbox(spobj)), proj4string = CRS(proj4string(spobj)))
  # convert to lat-long
  boxLL = bbox(spTransform(boxpts, CRS("+init=epsg:4326")))
  # find the centre
  llc = apply(boxLL, 1, mean)
  # construct the proj4 string
  prj = paste0("+proj=omerc +lat_0=", llc[2], " +lonc=", llc[1], " +alpha=", 
               angle, " +gamma=0.0 +k=1.000000 +x_0=0.000 +y_0=0.000 +ellps=WGS84 +units=m ")
  # return as a CRS:
  CRS(prj)
}

bnds <- cbind(x=c(site_first$long + .08, site_last$long + .1,  site_last$long - .175, site_first$long - .2), 
              y=c(site_first$lat  + .1, site_last$lat  + .05,  site_last$lat - .1, site_first$lat  - .05))
focus_poly <- SpatialPolygons(list(Polygons(list(Polygon(bnds)),"bbox")), proj4string=CRS("+init=epsg:4326")  )

# get the proj4 string
l2_Proj <- rotateProj(focus_poly, 56)
# transform
l2_focus_poly      <- spTransform(focus_poly, l2_Proj)
l2_watershed       <- rgeos::gIntersection(spTransform(cf_watershed, l2_Proj), l2_focus_poly)
l2_cities         <- spTransform(cf_cities, l2_Proj)
l2_river          <- rgeos::gIntersection(spTransform(cf_rivers, l2_Proj), l2_focus_poly)
l2_sites          <- spTransform(cfr_sites, l2_Proj)


pdf('./figures/main_map_level2.pdf', width = 8.5, height = 4)

plot(l2_focus_poly, col = 'grey90')
plot(l2_watershed, col = '#edf8b1', lwd = 0.1, add = TRUE, border = '#addd8e')

points(l2_cities, cex = .75, pch = 16)
# text(x = l2_cities$LONGITUDE[1],  y = l2_cities$LATITUDE[1], l2_cities$NAME[1], cex = .5)
# text(x = l2_cities$LONGITUDE[2],   y = l2_cities$LATITUDE[2],     l2_cities$NAME[2], cex = .35)

# Plot water features
lines(l2_river, col = water_col, lwd = 2)
# Plot non-LD sampling locations
points(x = l2_sites$long[1:11], y = l2_sites$lat[1:11] + 1000, cex = 1, col = 'red', pch = 6)
text(l2_sites$text_labels[1:11], x = l2_sites$long[1:11] + 200, y = l2_sites$lat[1:11] + 3000)
# Plot LD sampling locations
points(l2_sites[grepl('LD1', l2_sites$text_labels), ], cex = 1.2, col = 'red', pch = 20)
text(l2_sites$text_labels[12], x = l2_sites$long[12] - 1750, y = l2_sites$lat[12] + 2000)
dev.off()

