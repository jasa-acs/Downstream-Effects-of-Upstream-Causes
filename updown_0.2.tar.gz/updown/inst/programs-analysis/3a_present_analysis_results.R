#------------------------------------------------------------------------------#
#  Title: Create plots of CFR analysis for updownstream manuscript
#   Date: 12/05/2016
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

library(ggplot2)
#------------------------------------------------------------------------------#
# Functions to prepare results ####
#------------------------------------------------------------------------------#

prep_data_plot <- function(result_data, .scheme, .interval, .A_quant,
                           .N_L3_var, .P_L3_var,
                           .methods = c('gfm', 'msm', 'snm')){
  
  #### Prepare dataset for plotting ####
  # Pick which results to use
  dt <- result_data %>% 
    filter_(~ interval_id == .interval, 
            ~ scheme      == .scheme, 
            # ~ subscheme  == .subscheme,
            ~ A_quantile == .A_quant,
            ~ method     %in% .methods) %>%
    # Which space varying covariates to use
    filter_(~(A_var %in% c('nh3', 'no3', 'tkn') & L3_var == .N_L3_var) | 
              (A_var == 'p' & L3_var == .P_L3_var)) %>%
    ## Add labels 
    mutate_(Alabel =~ ifelse(A_var == 'nh3', 'NH[3]', toupper(A_var)),
            Alabel =~ ifelse(A_var == 'no3', 'NO[3]', Alabel)) %>%
    ungroup() %>%
    ## Clean up estimates from 'failures'
    group_by_(~A_var, ~L3_var, ~method) %>%
    # arrange_(~A_var, ~method) %>%
    # interpolated failed estimates
    mutate_(estimate = ~ approx(distance, estimate, xout = distance)$y) %>%
    # mutate_(estimate = ~ifelse(failed, (lag(estimate) + lead(estimate))/(lead(distkm) - lag(distkm)), estimate)) %>%
    # mutate_(estimate = ~ifelse(A_var == 'nh3' & cormp_id %in% c('B8302000', 'B8305000', 'B8306000') & method == 'msm',
    #                          (msm_nh3_repair_slope * distkm) + msm_nh3_repair_intercept , estimate)) %>%
    ungroup() %>%
    ## Pick confidence interval
    mutate_(
      ## Highlight cases where CI does not cross zero ##
      ysignificant      =~ conf.high + .15,
      cilo_extends_past =~ (conf.low < -3.5),
      cihi_extends_past =~ (conf.high > 3.5)) 
  
  dt 
}



plot_results <- function(plot_data, legend_pos = c(.12,  .83)){

  #### Plotting attributes ####
  nmethods    <- length(unique(plot_data$method))
  xbreaks     <- c(-unique(plot_data[plot_data$method == 'gfm', 'distkm'])$distkm, 0)
  xlabels     <- -round(xbreaks, 0)
  # Clean up overcrowded x-axis
  xlabels[xlabels == 55] <- '55  '
  xlabels[xlabels == 49] <- '  49'
  xlabels[xlabels ==  0] <- 'LD1   '
  
  ### Information for backgrounds and facetting ###
  bg_Avar     <- unique(plot_data$A_var)
  Alabel      <- ifelse(bg_Avar == 'nh3', 'NH[3]',
                        ifelse(bg_Avar == 'no3', 'NO[3]',
                               ifelse(bg_Avar == 'p', 'P',
                                      'TKN')))
  bg_color    <- c('col1', 'col2', 'col1', 'col2')
  backgrounds <- data_frame(Alabel = Alabel,
                            color = bg_color[1:length(bg_Avar)])
  last_bg     <- backgrounds$Alabel[nrow(backgrounds)]
  

  #### Begin build plot ####
  p <- ggplot(plot_data, aes(x = -distkm_jitter, y = estimate, 
                      group = method, 
                      color = method, 
                      size = factor(significant))) +
    ## Plot Geoms ##
    geom_rect(
      data = backgrounds, 
      # aes(fill = color), 
      fill = c('white', 'grey95', 'white', 'grey95'),
      xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf, alpha = .2,  
      linetype = 'solid',
    inherit.aes = FALSE) + 
    
    geom_text(data = backgrounds, aes(x = -130.000, y = 2.5, label = Alabel), hjust = 0, size = 6, 
              color = 'gray50', parse = TRUE, inherit.aes = FALSE) + 
    
    # X-axis
    geom_hline(yintercept = 0, color = 'grey65', linetype = 'solid', size = .5) +
    
    # Connect points
    geom_line(aes(linetype = method), size = .2,  inherit.aes = TRUE, na.rm = TRUE) +
    
    # Add Confidence intervals
    geom_linerange(aes(ymin = conf.low, ymax = conf.high), linetype = 'solid',
                   na.rm = TRUE) + 
    
    geom_point(
      data = dplyr::filter(plot_data, failed == FALSE), 
      aes(shape = method,
          fill  = method),
      size        = 0.8, 
      inherit.aes = TRUE, 
      na.rm       = TRUE) +
    
    geom_point(
      data = dplyr::filter(plot_data, failed == TRUE), 
      aes(shape = method),
               # shape = 5,
      fill        = 'white', 
      # alpha       = ,
      size        = 1.2, 
      inherit.aes = TRUE, 
      na.rm       = TRUE) +
    
    ## Add star for significant estimates 
    geom_point(data = dplyr::filter(plot_data, significant == TRUE), 
               aes(y = ysignificant), 
               shape = 8, 
               size = 1.2, inherit.aes = TRUE, na.rm = TRUE) +
    
    ## Plot indicators at CIs extend further
    geom_segment(data = dplyr::filter(plot_data, cilo_extends_past == TRUE), 
                 aes(y = -3.3, yend = -3.5, xend = -distkm_jitter), 
                 arrow = arrow(length = unit(0.1, "cm")), linetype = 'solid', 
                 inherit.aes = TRUE, na.rm = TRUE) +
    geom_segment(data = dplyr::filter(plot_data, cihi_extends_past == TRUE), 
                 aes(y = 3.3, yend = 3.5, xend = -distkm_jitter, size = factor(significant)), 
                 arrow = arrow(length = unit(0.1, "cm")), linetype = 'solid', 
                 inherit.aes = TRUE, na.rm = TRUE) +
    
    ## Scales ##
    scale_shape_manual(name = '', 
                       values = c(
                        'snm' = 23, # 18, 
                        'gfm' = 21, #16, 
                        'msm' = 24 #17
                        ), guide = FALSE) + 
    scale_color_manual(
      name = '', 
      values = c('snm' = "#4553c2", 
                 'gfm' = "#338821", 
                  'msm' = "#af1680", 
                  "#04451b"),
      labels = c('GFM', 'MSM', 'SNM')
    ) +
    scale_fill_manual(
      name = '', 
      values = c('snm' = "#4553c2", 
                 'gfm' = "#338821", 
                 'msm' = "#af1680", 
                 "#04451b"),
      guide = FALSE
    ) + 
    # scale_fill_manual(values = c('white', 'grey95'), guide = FALSE) + 
    scale_size_manual(name = '', values = c(.15, .55), guide = FALSE) + 
    scale_alpha_manual(name = '', values = c(1, .2), guide = FALSE) + 
    scale_linetype_manual(
      name = '', 
      values = c('snm' = 'solid',
                 'gfm' = 'longdash', 
                 'msm' = 'dotdash')
    ) + 
    guides( 
      color = guide_legend(
        order = 1,
        label.position = 'top',
        override.aes = list(shape = c(16, 17, 18),
                            size = 1.4,
                            linetype = rep("blank", nmethods))
        ),
      linetype = guide_legend(
        order = 2,
        title = NULL,
        label = FALSE,
        label.position = 'bottom',
        legend.theme = element_blank(),
        override.aes = list(alpha = 1,
                            size  = .65,
                            color  = c('gfm' = "#338821", 
                                       'msm' = "#af1680",
                                       'snm' = "#4553c2")
        )
      )) +

    ## Axis scales ##
    scale_x_continuous('', breaks = xbreaks, labels = xlabels) + 
    scale_y_continuous(name = expression(hat(mu)), 
                       breaks = c(-2, 0, 2), 
                       minor_breaks = c(-3, -1, 1, 3)) +
    coord_cartesian(xlim = c(0, -135.000), ylim = c(-3.5, 3.5), expand = FALSE) + 
    facet_grid(Alabel ~ ., labeller = label_parsed) + 
    
    ## Annotations ##
    geom_text(data = data.frame(x = -132, y = -3.4, Alabel = last_bg), aes(x = x, y = y), 
              hjust = 0, vjust = 0, size = 3, color = 'gray50',
              label = 'River km upstream of LD1', inherit.aes = FALSE) + 
    
    ## Theme Modifications ##
    theme_classic() +
    theme(axis.text.x  = element_text(size = 8, color = 'grey50'),
          axis.title.x = element_text(vjust = 0, hjust = 1, size = 8),
          axis.line.x  = element_line(color = 'grey50'),
          axis.text.y  = element_text(size = 8, color = 'grey50'),
          axis.title.y = element_text(angle = 0, vjust = .9, color = 'grey50'),
          axis.ticks   = element_line(color = 'grey50', size = .1),
          legend.position    = legend_pos,
          legend.background  = element_rect(fill = NA),
          legend.direction   = 'horizontal',
          legend.text        = element_text(size = 8, color = 'grey50'),
          legend.spacing     = unit(0, 'lines'),
          legend.key.width   = unit(2, 'lines'),
          legend.key.height  = unit(.1, 'lines'),
          panel.grid.major.x = element_blank(),
          # panel.grid.major.x = element_line(color = "grey75", size = 0.15),
          panel.grid.minor.x = element_blank(),
          panel.grid.major.y = element_line(colour= "grey70", size=0.15),
          panel.grid.minor.y = element_line(colour= "grey80", size=0.05),
          strip.background   = element_rect(color = 'white'),
          strip.text         = element_blank())
  
  p
}

#------------------------------------------------------------------------------#
# Test Plot results ####
#------------------------------------------------------------------------------#

prep_data_plot(cfrresults,
               .scheme    = 'A',
               # .subscheme = 'b',
               .interval  = 'I7',
               .A_quant   = .5,
               .N_L3_var  = 'p',
               .P_L3_var  = 'nh3') %>%
  plot_results()

prep_data_plot(cfrresults_impute,
               .scheme    = 'A',
               # .subscheme = 'b',
               .interval  = 'I7',
               .A_quant   = .5,
               .N_L3_var  = 'p',
               .P_L3_var  = 'nh3') %>%
  plot_results()
