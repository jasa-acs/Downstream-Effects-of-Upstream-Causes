#------------------------------------------------------------------------------#
#   Title: Prep functions and schemes for CFR analysis 
#    Date: 11/22/2016
#  Author: Bradley Saul
# Purpose: Contains the functions that prepare analysis for a specific analysis
#          method. Contains weight schomes for MSMs. Contains model schemes - 
#          information on the parameterization of the outcome and exposure models
#          plus variance estimation options.
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
# Data preparation functions ####
#------------------------------------------------------------------------------#

## Gformula ####
prep_cfr_data_gform <- function(data, Qformula, Lformula){
  data <- data %>% filter_(~ s == 2, ~t > 0)
  Qmodel <- do.call(geepack::geeglm, args = list(formula = Qformula,
                                                 family = gaussian,
                                                 id     = quote(ID),
                                                 data   = data))
  
  Lmodel <- do.call(geepack::geeglm, args = list(formula = Lformula,
                                                 family = gaussian,
                                                 id     = quote(ID),
                                                 data   = data))
  list(data = data, Q = Qmodel, L = Lmodel)
}


## MSM #####
prep_cfr_data_msm <- function(data, group_var, weight_scheme){
  data <- compute_weights(data = data,
                          scheme = weight_scheme,
                          weight_names = c('W1', 'SW1'),
                          idvar = group_var,
                          extra_mutate = setNames(list(~nm, ~dn), c('pa.1', 'pal.1'))) %>%
    arrange(ID)
  
  ## Nontargets ##
  nuisance_models <- lapply(weight_scheme, function(x){
    thisdt <- data %>% filter_(x$filter)
    if(is.null(x$numerator)) {ff <- x$denominator } else {ff <- x$numerator}
    args <- append(x$method_opts, list(data = thisdt, formula = ff))
    m    <- do.call(x$method, args = args)
    
    list(m = m, filter = x$filter)
  })
  
  list(data = data, nm = nuisance_models)
}

## SNM #####
prep_cfr_data_snm <- function(Aformula,
                               Amodel_method,
                               Amodel_method_opts,
                               Y1formula,
                               Y2formula,
                               Ymodel_method,
                               Ymodel_method_opts,
                               data){
  
  Amodel <- model(formula = Aformula,
                  data        = data,
                  method      = Amodel_method,
                  method_opts = Amodel_method_opts)
  
  Y1model <- model(formula = Y1formula,
                   data        = data %>% filter(s == 2),
                   method      = Ymodel_method,
                   method_opts = Ymodel_method_opts)
  
  Y2model <- model(formula = Y2formula,
                   data        = data %>% filter(s == 2),
                   method      = Ymodel_method,
                   method_opts = Ymodel_method_opts)
  
  Ydata <- data %>%
    filter_(~ s == 2) %>%
    mutate_(f_Y2 =~ fitted(Y2model),
            f_Y1 =~ fitted(Y1model)) %>%
    select_(~ID, ~t, ~s, ~f_Y2, ~f_Y1)
  
  data <- data %>% mutate_(
    f_A = ~ fitted(Amodel),
    f_A_slag1 = ~ ifelse(s == 2, dplyr::lag(f_A), NA)) %>%
    left_join(Ydata, by = c('ID', 't', 's'))
  
  list(data = data, Amodel = Amodel, Y1model = Y1model, Y2model = Y2model)
}

## GEE ####
prep_cfr_data_gee <- function(data, Qformula){
  data <- data %>% filter_(~ s == 2)
  Qmodel <- do.call(geepack::geeglm, args = list(formula = Qformula,
                                                 family = gaussian,
                                                 id     = quote(ID),
                                                 data   = data))
  list(data = data, Q = Qmodel)
}

#------------------------------------------------------------------------------#
## Model & Analysis schemes #####
#------------------------------------------------------------------------------#

#### Anlysis A ####

cfr_weight_scheme_A <-list( 
  list(filter      = ~ s == 1 & t == 1,
       numerator   = A ~ 1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 1 & t > 1,
       numerator   = A ~ A_tlag1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 2 & t > 0,
       numerator   = A ~ A_tlag1 + A_slag1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 1 & t > 0,
       numerator   = NULL,
       denominator = A ~ flow + temp + A_tlag1,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 2 & t > 0,
       numerator   = NULL,
       denominator = A ~ flow + temp + L3 + A_slag1 + A_tlag1,
       method      = 'glm',
       method_opts = list(family = 'binomial')))

scheme_Aa <- list(
  Qformula         = Y_slead1 ~ A + A_slag1 + flow + temp + L3 + Y_tlag1_slead1,
  Lformula         = L3 ~ flow + temp + L3_tlag1 + A_slag1,
  gfm_Lvar         = 'L3',
  msm_formula      = Y_slead1 ~ -1 + factor(t) + A + A_slag1,
  msm_scheme       = cfr_weight_scheme_A,
  snm_Aformula     = A ~ flow + temp + L3 + A_slag1 + A_tlag1,
  snm_Amethod      = 'glm',
  snm_Amethod_opts = list(family = binomial(link = 'logit')),
  snm_Y1formula    = Y_slead1 ~ flow + temp + L3,
  snm_Y2formula    = Y_slead1 ~ flow_slag1 + temp_slag1,
  snm_Ymethod      = 'lm',
  snm_Ymethod_opts = NULL,
  numDerivOpts     = list(method = 'Richardson', method.args = list(r = 15)),
  corrections = list(
    bias_.75 = correction(FUN = fay_bias_correction, b = 0.75),
    bias_.3  = correction(FUN = fay_bias_correction, b = 0.3),
    bias_.1  = correction(FUN = fay_bias_correction, b = 0.1)))

#### Scheme B ####
# include temp*discharge interaction in exposure and outcome models

cfr_weight_scheme_B <-list( 
  list(filter      = ~ s == 1 & t == 1,
       numerator   = A ~ 1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 1 & t > 1,
       numerator   = A ~ A_tlag1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 2 & t > 0,
       numerator   = A ~ A_tlag1 + A_slag1,
       denominator = NULL,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 1 & t > 0,
       numerator   = NULL,
       denominator = A ~ flow*temp + A_tlag1,
       method      = 'glm',
       method_opts = list(family = 'binomial')),
  list(filter      = ~ s == 2 & t > 0,
       numerator   = NULL,
       denominator = A ~ flow*temp + L3 + A_slag1 + A_tlag1,
       method      = 'glm',
       method_opts = list(family = 'binomial')))

scheme_Ba <- list(
  Qformula      = Y_slead1 ~ A + A_slag1 + flow*temp + L3 + Y_tlag1_slead1,
  Lformula      = L3 ~ flow + temp + L3_tlag1 + A_slag1,
  gfm_Lvar      = 'L3',
  msm_formula   = Y_slead1 ~ -1 + factor(t) + A + A_slag1,
  msm_scheme    = cfr_weight_scheme_B,
  snm_Aformula  = A ~ flow*temp + L3 + A_slag1 + A_tlag1,
  snm_Amethod   = 'glm',
  snm_Amethod_opts = list(family = binomial(link = 'logit')),
  snm_Y1formula = Y_slead1 ~ flow*temp + L3,
  snm_Y2formula = Y_slead1 ~ flow_slag1*temp_slag1,
  snm_Ymethod   = 'lm',
  snm_Ymethod_opts = NULL,
  numDerivOpts  = list(method = 'Richardson', method.args = list(r = 15)),
  corrections = list(
    bias_.75 = correction(FUN = fay_bias_correction, b = 0.75),
    bias_.3  = correction(FUN = fay_bias_correction, b = 0.3 ),
    bias_.1  = correction(FUN = fay_bias_correction, b = 0.1 )))
