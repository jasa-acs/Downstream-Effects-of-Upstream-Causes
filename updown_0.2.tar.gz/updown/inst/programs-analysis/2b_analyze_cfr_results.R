#------------------------------------------------------------------------------#
#   Title: Review results of CFR analysis
#    Date: 12/05/2016
#  Author: Bradley Saul
# Purpose: Create the analysis dataset to use in analysis of the Cape Fear River
#          based on a subset of the full CFR dataset. Handles missing data.
#------------------------------------------------------------------------------#

library(updown)
library(capefear)
library(ggplot2)
library(dplyr)

analysis_date <- "20171205"
input_file <- paste0("inst/programs-analysis/results/", analysis_date, 
                     "_cfr_results.rda")
load(file =  input_file)
#------------------------------------------------------------------------------#
# Prepare analyzed data for review and plotting ####
#------------------------------------------------------------------------------#
alpha <- .1

interval_id_fun <- function(distr, correction){
  switch(paste(distr, correction, sep = '_'),
         'N_'      = 'I1',
         'N_bc_3'  = 'I2',
         'N_bc_2'  = 'I3',
         'N_bc_1'  = 'I4',
         't_'      = 'I5',
         't_bc_3'  = 'I6',
         't_bc_2'  = 'I7',
         't_bc_1'  = 'I8')
}

interval_id_fun <- Vectorize(interval_id_fun)

critical_values <- 
  expand.grid(distr = c('N', 't'), m = unique(cfr_results$m), stringsAsFactors = FALSE) %>%
  mutate_(critical_value = ~ ifelse(distr == 'N', 
                                    qnorm(1 - alpha/2, mean = 0, sd =1),
                                    qt(1 - alpha/2, df = m)) )

cfrresults <- cfr_results %>% 
  dplyr::select_(~ -analysisdt, ~ -schema) %>%
  tidyr::unnest() %>%
  tidyr::gather(var_type, std_error_val, -m, -A_var, -L3_var, -A_quantile,
                -s1, -s2, -s1_site, -s2_site, -s3_site, -Acutpoint, -scheme_name, 
                -method, -message, -term, -estimate) %>%
  mutate_(var_correction = ~ substr(var_type, 11, 99)) %>%
  merge(data_frame(distr = c('N', 't')), all = TRUE) %>%
  left_join(critical_values, by = c('distr', 'm')) %>%
  # Create conf intervals
  mutate_(conf.high      = ~ estimate + critical_value * std_error_val,
          conf.low       = ~ estimate - critical_value * std_error_val,
          interval_id    = ~ as.character(interval_id_fun(distr, var_correction))) %>%
  # Create p-values
  mutate_(pval = ~ ifelse(distr == 'N', pnorm(abs(estimate/std_error_val), lower.tail = FALSE),
                          pt(abs(estimate/std_error_val), df = m, lower.tail = FALSE))) %>%

  # Add site information to the data
  dplyr::select(cormp_id = s2_site, everything()) %>%
  left_join(sites %>% dplyr::select(cormp_id, distance, location, comment), 
            by = 'cormp_id') %>%
  

  # Create variables needed for plotting
  mutate_(
    scheme        =~ substr(scheme_name, 8, 8),
    subscheme     =~ substr(scheme_name, 9, 9),
    ## Hardcode x-axis jitter to causal methods ##
    dist_jitter   =~ ifelse(method == 'gee', distance - 1800,
                      ifelse(method == 'msm', distance - 600,
                        ifelse(method == 'snm', distance - 1200, distance))),
    distkm_jitter =~ dist_jitter/1000,
    distkm        =~ distance/1000,
    significant   =~ (conf.low > 0 | conf.high < 0) * 1,
    failed        =~ is.na(estimate)) 

rm(critical_values, alpha, interval_id_fun)

#------------------------------------------------------------------------------#
# Prepare analyzed data for review and plotting ####
#------------------------------------------------------------------------------#

# cfrresults %>%
#   # filter(scheme == 'A') %>%
#   filter(conf_type == 1) %>%
#   filter(method != 'gee') %>%
#   filter(abs(estimate) < 4) %>%
#   filter(A_quantile == 0.5) %>% 
#   # Which space varying covariates to use
#   filter_(~(A_var %in% c('nh3', 'no3', 'tkn') & L3_var == 'p') | (A_var == 'p' & L3_var == 'nh3')) %>%
# ggplot(., aes(x = estimate, y = -log10(p.8), color = method)) + 
#   geom_point() + 
#   facet_grid(A_var ~ scheme + subscheme) + 
#   geom_hline(yintercept = 1)
