#------------------------------------------------------------------------------#
#   Title: Create CFR analysis dataset
#    Date: 11/22/2016
#  Author: Bradley Saul
# Purpose: Create the analysis dataset to use in analysis of the Cape Fear River
#          based on a subset of the full CFR dataset. Handles missing data.
#------------------------------------------------------------------------------#

library(updown)
library(capefear)
library(lazyeval)
library(Hmisc)
LD1 <- "B8349000"
#------------------------------------------------------------------------------#
# Make prelim data from which to create analysis datasets ####
#------------------------------------------------------------------------------#

prelim <- cfwq_main %>%
  #### Inclusion / Exclusion ####
# Include records from April thru October
filter(month %in% c("Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct")) %>%
  # Include sites with chlorophyll data
  # AND initally include the two sites upstream of B829000 in order to get values for
  # lagged covariates these will be dropped later.
  # filter(has_any_chlorophyll_site == 1 | cormp_id %in% c('B7480000', 'B7500000')) %>%
  
  # Exclude 2013 and prior to 1998
  filter(year < 2013 & year > 1998) %>%
  
  # Exclude sites more than 145km upstream or any distance downstream of LD1
  filter(abs(distance) < 185000, distance >= 0) %>%
  
  #### END Inclusion / Exclusion ###
  mutate_(year  = ~as.numeric(year),
         month  = ~as.numeric(month),
         distance_lock1_km = ~distance/1000) %>%
  dplyr::rename_(PH = ~ph) %>%
  
  # Remove unnecessary variables
  dplyr::select(-ends_with('remark'), -ends_with('censor'),
         -county, -location, -qc, -year_month, -date_time, -date, -usgs_id,
         -has_any_chlorophyll_site, -huc, -is_main, -lat, -long,
         -hardness, -enterococcus) %>%
  
  # There are some cases of >1 obs in month. Taking average of these.
  group_by(year, month, cormp_id) %>%
  mutate(n_obs = n()) %>%
  summarise_all(funs(mean(. , na.rm = T))) %>%
  ungroup %>%
  
  # Make the data have one observation per site, year, month so that
  # the data is balanced.
  right_join(expand.grid(cormp_id = unique(.$cormp_id),
                         year     = unique(.$year),
                         month    = unique(.$month),
                         stringsAsFactors = FALSE),
             by = c('cormp_id', 'year', 'month')) %>%
  
  # Make sure that flow_order and distance variables are set
  dplyr::select(-flow_order, -distance) %>%
  left_join(dplyr::select(sites, cormp_id, flow_order, distance), by = 'cormp_id')

#------------------------------------------------------------------------------#
# missing data summary ####
#------------------------------------------------------------------------------#

# Missing covariates #

# Across May - September
prelim %>%
  filter(month %in% 5:9, cormp_id != LD1) %>%
  select(nh3, tkn, p, no3, temp, discharge_lag3mean, do) %>%
  summarize_all(.funs = funs(nmissing = sum(is.na(.))))
# Across June - September
prelim %>%
  filter(month %in% 6:9, cormp_id != LD1) %>%
  select(nh3, tkn, p, no3, temp, discharge_lag3mean, do) %>%
  summarize_all(.funs = funs(nmissing = sum(is.na(.))))

# Across May - September after imputation
prelim %>%
  filter(month %in% 6:9, cormp_id != LD1) %>%
  group_by(year, month) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(.) + lead(.))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, do, PH)) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(., 2) + lead(., 2))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, do, PH)) %>%
  group_by(year, cormp_id) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(.) + lead(.))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, do, PH))  %>%
  ungroup() %>%
  # filter(is.na(p))
  # filter(is.na(tkn))
  dplyr::select(nh3, tkn, p, no3, temp, discharge_lag3mean, do) %>%
  summarize_all(funs(nmissing = sum(is.na(.))))

# Missing LD1 chlorophll #
prelim %>%
  filter(month %in% 5:9, cormp_id == LD1) %>%
  dplyr::select(chlorophyll) %>%
  summarize_all(funs(nmissing = sum(is.na(.))))

#------------------------------------------------------------------------------#
# Handle missing data ####
#------------------------------------------------------------------------------#

# Make hardcoded imputations for missing chlorophyll values
prelim <- prelim %>%
  mutate(
    chlorophyll = ifelse(year == 2004 & month == 7 & cormp_id == "B8349000", (5.74 + 9.6)/2, chlorophyll),
    chlorophyll = ifelse(year == 2000 & month == 5 & cormp_id == "B8349000", (6.9 + 5.99)/2, chlorophyll) )

# Updated imputation used for stability analysis
imputed_results <- 
  aregImpute(~ year + month + cormp_id + distance + discharge_lag3mean + temp + PH + do + nh3 + tkn + no3 + p,
             data = prelim, n.impute = 5, nk = 4, match = "closest", type = "pmm")

imputed_values <- imputed_results$imputed 
which_vars     <- lapply(imputed_values, function(x) !is.null(x)) %>% unlist
imputed_vars   <- names(imputed_values)[which_vars]
out <- lapply(1:imputed_results$n.impute, function(x) prelim)

# Replace values
lapply(seq_along(out), function(kk){
  hold <- out[[kk]]
  for(i in 1:length(imputed_vars)){
    hold <- get("hold")
    var_name    <- imputed_vars[i]
    replace_pos <- as.integer(row.names(imputed_values[[var_name]]))
    hold[[var_name]][replace_pos] <- imputed_values[[var_name]][ , kk]
  }
  hold
}) -> imputed_data


# Simple imputation used in original JASA submission
prelim <- prelim %>%
  group_by(year, month) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(.) + lead(.))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, PH, do)) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(., 2) + lead(., 2))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, do, PH)) %>%
  group_by(year, cormp_id) %>%
  mutate_at(.funs = funs(ifelse(is.na(.), (lag(.) + lead(.))/2, .)), 
            .vars = vars(temp, p, nh3, no3, tkn, do, PH)) 

#------------------------------------------------------------------------------#
# Create temporally and spatially lagged variables ####
#------------------------------------------------------------------------------#

add_spacetime_variables <- function(input_data){
  input_data %>%
    # spatially lagged 
    group_by_(~year, ~month) %>%
    mutate_at(.funs = funs(slag1 = lag(.) ),  
              .vars = vars(p, nh3, no3, tkn, do, PH)) %>%
    # temporally lagged
    group_by_(~year, ~cormp_id) %>%
    mutate_at(.funs = funs(tlag1 = lag(.), tlag2 = lag(., 2)), 
              .vars = vars(p, nh3, no3, tkn, do, PH)) %>%
    filter(abs(distance) < 145000) 
}

simple_impute_data  <- add_spacetime_variables(prelim) 
complex_impute_data <- lapply(imputed_data, add_spacetime_variables)

#------------------------------------------------------------------------------#
# Make analysis data function ####
#------------------------------------------------------------------------------#

make_analysisdt <- function(input_data, upstream_sites, months, A_var, A_quantile, L3_var){
  
  # Use -1 as indication to log transform A instead of discretize
  if(A_quantile != -1){
    # Identify cutpoint
    A_cutpoint <- input_data %>%
      filter_(~cormp_id %in% upstream_sites[1:2]) %>%
      arrange(year) %>% filter_(~year == 1999)  %>% ungroup() %>%
      summarise_(A_cutpoint = interp(~ quantile(var, cutp ),
                                     var  = as.name(A_var),
                                     cutp = A_quantile)) %>%
      as.numeric()
    
    transformA <- function(x){
      (x > A_cutpoint) * 1
    }
  } else {
    transformA <- function(x){
      log(x)
    }
  }

  # Create dataset
  input_data %>%
    filter_(~month %in% months, ~cormp_id %in% upstream_sites) %>%
    arrange(year, -distance, month) %>%
    group_by(year, month)    %>% mutate(s = 1:n()) %>%          # Spatial Index
    group_by(year, cormp_id) %>% mutate(t = 0:(n() - 1) ) %>%   # Temporal Index
    ungroup() %>%
    arrange(year, s, t) %>%
    
    # Spatially lag/lead variables
    group_by_(~year, ~t) %>%
    # mutate_each_(funs(slag1 = lag(.) ),  vars(p, nh3, no3, tkn, do)) %>%
    mutate_at(.funs = funs(slead1 = lead(.)), setNames('chlorophyll', 'chlorophyll')  ) %>%
    # Temporally lag/lead variables
    group_by_(~year, ~s) %>%
    # mutate_each_(funs(tlag1 = lag(.), tlag2 = lag(., 2)), vars(p, nh3, no3, tkn, do)) %>%
    mutate_at(.funs = funs(tlag1 = lag(.)), setNames('chlorophyll_slead1', 'chlorophyll_slead1')  ) %>%
    ungroup()   %>%

    # Set missing lagged variables to 0
    mutate_at(.funs = funs(ifelse(is.na(.), 0, .)), .vars = vars(contains('lag'))) %>%

    # Rename variables
    rename_(.dots = setNames(names(.), gsub(paste0('^', A_var), 'A', names(.)))) %>%
    rename_(.dots = setNames(names(.), gsub(paste0('^', L3_var), 'L3', names(.)))) %>%

    # Set up variables for final dataset
    mutate_(Y_slead1 = ~ log2(chlorophyll_slead1),
            Y_tlag1_slead1 = ~ log2(chlorophyll_slead1_tlag1),
            # Values of Y should be missing for all but s = 2
            Y_slead1 = ~ ifelse(s != 2, NA, Y_slead1),
            Y_tlag1_slead1 = ~ ifelse(s != 2, NA, Y_tlag1_slead1),
            flow     = ~ discharge_lag3mean,
            temp     = ~ temp) %>%
    mutate_at(.funs = funs(ifelse(is.na(.), 0, .)), .vars = vars(matches("^A"))) %>%
    # Spatially lag/lead variables
    group_by_(~year, ~t) %>%
    mutate_at(.funs = funs(slag1 = lag(.) ), .vars = vars(flow, temp)) %>%
    # mutate_each_(funs((. > A_cutpoint) * 1), vars(matches('^A'))) %>%
    mutate_at(.funs = funs(transformA), .vars = vars(matches('^A'))) %>%
    mutate_at(.funs = funs(log(.)), .vars = vars(matches('^L3'))) %>%

    # Keep analysis variables and observations of interest
    select_(ID = ~year, ~s, ~t, ~Y_slead1, ~Y_tlag1_slead1, ~matches('^A'),
            ~matches('^(L3|temp|flow)')) %>%
    filter_(~t > 0, ~s %in% 1:2) %>%

    # Exclude years where > 0 exposure or time-varying covariate is missing
    group_by_(~ID) %>%
    filter_(~ sum(is.na(A)) == 0, ~ sum(is.na(L3) | L3 == -Inf) == 0) %>%
    ungroup() %>%

    # Keep the Cutpoint
    mutate_(Acutpoint = ~ ifelse(A_quantile!= -1, A_cutpoint, NA))
}

#------------------------------------------------------------------------------#
# Create analysis settings ####
#------------------------------------------------------------------------------#

prelim_sites <- unique(simple_impute_data$cormp_id)
sitedf <- data_frame(s1      = 1:(length(prelim_sites) - 2), 
                     s2      = s1 + 1, 
                     s1_site = prelim_sites[s1], s2_site = prelim_sites[s2], 
                     s3_site = LD1) 

analysis_settings <- expand.grid(A_var      = c('nh3', 'tkn', 'no3', 'p'), 
                                L3_var     = c('nh3', 'tkn', 'no3', 'p', 'do', 'PH'),
                                A_quantile = c(0.25, 0.5, 0.75, -1),
                                stringsAsFactors = FALSE) %>% 
  arrange(A_var) %>%
  filter(!(A_var == L3_var)) %>%
  merge(sitedf, all = TRUE) %>%
  # filter(row_number() == 45) %>%
  rowwise() 

#------------------------------------------------------------------------------#
# Create analysis dataset(s) ####
#------------------------------------------------------------------------------#

## Testing ##
# test1 <- make_analysisdt(simple_impute_data,
#                 c(prelim_sites[1], prelim_sites[2], LD1),
#                 months     = 5:9,
#                 A_var      = 'no3',
#                 A_quantile = .5,
#                 L3_var     = 'PH') 
# test2 <- make_analysisdt(prelim,
#                          c(prelim_sites[1], prelim_sites[2], LD1),
#                          months     = 5:9,
#                          A_var      = 'no3',
#                          A_quantile = .5,
#                          L3_var     = 'PH') 

cfr_analysisdt <- analysis_settings %>%
  mutate_(analysisdt = ~ list(make_analysisdt(simple_impute_data,
                                              c(s1_site, s2_site, s3_site),
                                              months     = 5:9,
                                              A_var      = A_var,
                                              A_quantile = A_quantile,
                                              L3_var     = L3_var) ),
          m = ~ length(unique(as.data.frame(analysisdt)$ID)),
          Acutpoint =~ as.data.frame(analysisdt)$Acutpoint[1])

# Now do the same (for a subset of settings) with complex_impute_data
# doing this for the primary results presented in the manuscript (figure 5)

lapply(complex_impute_data, function(x) {
  analysis_settings %>%
    filter(
      (A_var == "nh3" & L3_var == "p")  |
        (A_var == "no3" & L3_var == "p")  |
        (A_var == "tkn" & L3_var == "p")  |
        (A_var == "p"  & L3_var == "nh3"),
      A_quantile == 0.5
    ) %>%
    mutate_(analysisdt = ~ list(make_analysisdt(x,
                                                c(s1_site, s2_site, s3_site),
                                                months     = 5:9,
                                                A_var      = A_var,
                                                A_quantile = A_quantile,
                                                L3_var     = L3_var) ),
            m = ~ length(unique(as.data.frame(analysisdt)$ID)),
            Acutpoint =~ as.data.frame(analysisdt)$Acutpoint[1])
}) -> cfr_analysisdt_complex_impute



#------------------------------------------------------------------------------#
# Save analysis dataset(s) ####
#------------------------------------------------------------------------------#

save(cfr_analysisdt, file = paste0("inst/programs-analysis/results/cfr_analysisdt_", 
                                  format(Sys.Date(), "%Y%m%d"), ".rda"))
# To do for multiple imputation
save(cfr_analysisdt_complex_impute, 
     file = paste0("inst/programs-analysis/results/cfr_analysisdt_complex_impute_", 
                                   format(Sys.Date(), "%Y%m%d"), ".rda"))

#------------------------------------------------------------------------------#
# Clean up ####
#------------------------------------------------------------------------------#
rm(LD1, prelim_sites, sitedf, make_analysisdt, prelim, out, 
   imputed_values, imputed_results, analysis_settings, imputed_data,
   imputed_vars, which_vars, simple_impute_data, add_spacetime_variables)
