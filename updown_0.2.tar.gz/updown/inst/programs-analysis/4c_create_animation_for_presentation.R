#------------------------------------------------------------------------------#
#  Title: Create animated gif for presentation
#   Date: 1/11/17
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#
library(rgdal)
library(capefear)

# Map data downloaded from: https://gdg.sc.egov.usda.gov

water_features_l <- readOGR(dsn = "map_data/hydrography_NHD24K_extract_3363657_01",  
                            layer = "nhd24kst_l_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

water_features_a <- readOGR(dsn = "map_data/hydrography_NHD24K_extract_3363657_01",  
                            layer = "nhd24kwb_a_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

water_features_p <- readOGR(dsn = "map_data/hydrography_NHD24K_extract_3363657_01",  
                            layer = "nhd24kpe_p_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

watershed <- readOGR(dsn = "map_data/hydrologic_units_WBDHU8_extract_3364500_02",  
                     layer = "wbdhu8_a_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

NC <- readOGR(dsn = "map_data/government_units_NRCSTATE_nc_3363589_01",  
              layer = "state_nrcs_a_nc") %>%
  spTransform(CRS("+init=epsg:4326"))

towns <- readOGR(dsn = "map_data/geographic_names_GNISPOP_extract_3364500_01",  
                 layer = "gnispop_p_extract") %>%
  spTransform(CRS("+init=epsg:4326"))

### Update data and grab necessary pieces ####

cf_watershed <- rgeos::gIntersection(rgeos::gUnaryUnion(watershed[grepl('0303000[2-7]', watershed$HUC8), ]), NC)
cf_rivers <- rgeos::gIntersection(water_features_l[grepl('Cape Fear River|Haw River|Deep River', water_features_l$GNIS_NAME), ], cf_watershed)
black_river <- water_features_l[water_features_l$GNIS_NAME == 'Black River' & grepl('^00981539', water_features_l$GNIS_ID), ]
cf_jordan  <- rgeos::gIntersection(water_features_a[grepl('B Everett Jordan Lake', water_features_a$GNIS_NAME), ], cf_watershed)
cf_cities <- towns[grepl('Wilmington$|^Fayetteville$|Greensboro|Chapel Hill|Elizabethtown', towns$NAME), ]


cfr_sites <- filter(sites, cormp_id %in% 
                      c(unique(c(cfr_results$s1_site, cfr_results$s2_site)), 'B8349000') )
cfr_sites <- SpatialPointsDataFrame(coords = as.matrix(cfr_sites[, c('long', 'lat')]),
                                    data = cfr_sites, proj4string = CRS("+init=epsg:4326"))
cfr_sites$distkm <- round(cfr_sites$distance/1000)
cfr_sites$text_labels <- c('', '', 'LD3', '', '', '', '',  '', 'LD2', '', '', 'LD1')
site_first <- cfr_sites[1, ]
site_last  <- cfr_sites[nrow(cfr_sites), ]

## Rotate objects to plot
rotateProj = function(spobj, angle) {
  # get bounding box as spatial points object
  boxpts = SpatialPoints(t(bbox(spobj)), proj4string = CRS(proj4string(spobj)))
  # convert to lat-long
  boxLL = bbox(spTransform(boxpts, CRS("+init=epsg:4326")))
  # find the centre
  llc = apply(boxLL, 1, mean)
  # construct the proj4 string
  prj = paste0("+proj=omerc +lat_0=", llc[2], " +lonc=", llc[1], " +alpha=", 
               angle, " +gamma=0.0 +k=1.000000 +x_0=0.000 +y_0=0.000 +ellps=WGS84 +units=m ")
  # return as a CRS:
  CRS(prj)
}

bnds <- cbind(x=c(site_first$long + .08, site_last$long + .1,  site_last$long - .175, site_first$long - .2), 
              y=c(site_first$lat  + .1, site_last$lat  + .05,  site_last$lat - .1, site_first$lat  - .05))
focus_poly <- SpatialPolygons(list(Polygons(list(Polygon(bnds)),"bbox")), proj4string=CRS("+init=epsg:4326")  )

# get the proj4 string
l2_Proj <- rotateProj(focus_poly, 56)
# transform
l2_focus_poly      <- spTransform(focus_poly, l2_Proj)
l2_watershed       <- rgeos::gIntersection(spTransform(cf_watershed, l2_Proj), l2_focus_poly)
l2_cities         <- spTransform(cf_cities, l2_Proj)
l2_river          <- rgeos::gIntersection(spTransform(cf_rivers, l2_Proj), l2_focus_poly)
l2_sites          <- spTransform(cfr_sites, l2_Proj)



#------------------------------------------------------------------------------#
# Map for manuscript plot ####
#------------------------------------------------------------------------------#

source('programs-analysis/')

plot_results_part <- function(dist_km, Avar, Lvar){
  prep_data_plot(cfrresults %>% filter_(~A_var == Avar),
                 .scheme    = 'A',
                 .interval  = 'I7',
                 .A_quant   = .5,
                 .N_L3_var  = Lvar,
                 .P_L3_var  = Lvar) %>% 
    mutate_(estimate    =~ ifelse(distkm < dist_km, NA, estimate),
            significant =~ ifelse(distkm < dist_km, NA, significant),
            conf.low    =~ ifelse(distkm < dist_km, NA, conf.low),
            conf.high   =~ ifelse(distkm < dist_km, NA, conf.high)) %>%
    plot_results(legend_pos = 'bottom')
}





plot_map_part <- function(i){
  function(){
    par(mai = c(0, 0, 0, 0), oma = c(0, 0, 0, 0))
    plot(l2_focus_poly, lty = 0)
    # Plot water features
    lines(l2_river, col = water_col, lwd = 2)
    # Plot non-LD sampling locations
    points(x = l2_sites$long[1:11], y = l2_sites$lat[1:11] + 1000, cex = 1, col = 'black', pch = 6, bg = 'white')
    text(l2_sites$text_labels[1:11], x = l2_sites$long[1:11] + 200, y = l2_sites$lat[1:11] + 3000)
    points(x = l2_sites$long[i:(i+1)], y = l2_sites$lat[i:(i+1)]+ 1000, cex = 1, col = 'red', pch = 25, bg = 'red')
    text(l2_sites$text_labels[i:(i+1)], x = l2_sites$long[i:(i+1)] + 200, y = l2_sites$lat[i:(i+1)] + 3000, col = 'red')
    # Plot LD1 sampling locations
    points(l2_sites[grepl('LD1', l2_sites$text_labels), ], cex = 1.2, col = 'red', pch = 20)
    text(l2_sites$text_labels[12], x = l2_sites$long[12] - 1750, y = l2_sites$lat[12] + 2000)
  }
}

## Plotting Settings ####

water_col <- '#1f78b4'
watershed_col <- '#edf8b1'

distances <- unique(cfrresults$distkm)

make_images <- function(Avar, Lvar){
  for(i in seq_along(distances)){
    
    pdf(file = paste0('figures/animation/', Avar, '_', stringr::str_pad(i - 1, 2, pad = '0'), '.pdf'), width = 6, height = 4)
    # Make figure areas
    topVp <- viewport(name = 'base', width  = unit(6, 'inches' ), height = unit(4, 'inches' ))
    
    main <- viewport(y = 1, name = 'main', width  = unit(6, 'inches' ), height = unit(2.5, 'inches' ),
                     just = 'top', clip = 'off')
    
    map <- viewport(x = .52, y = 0.0, name = 'map', width  = unit(6, 'inches' ), height = unit(2.5, 'inches' ),
                    just = 'bottom', clip = 'off')
    
    splot <- vpTree(topVp, vpList(main, map))
    pushViewport(splot)
    seekViewport('base')
    grid.rect(gp=gpar(fill="white", col = 'white')) 
    
    ## Print analysis graphics
    seekViewport('main')
    p <- plot_results_part(distances[i], Avar, Lvar)
    print(p, newpage = FALSE)
    
    seekViewport('map')
    # grid.rect(gp=gpar(lty="dashed"))
    q <- plot_map_part(i)
    grid.echo(q, newpage = FALSE)
    
    dev.off()
  }
}


make_images('no3', 'p') 
make_images('nh3', 'p') 
make_images('tkn', 'p') 
make_images('p', 'nh3') 


# convert -density 300 no3*.pdf no3_%02d.png
# convert -delay 100 -loop 5 no3*.png no3.gif
# convert -density 300 tkn*.pdf tkn_%02d.png
# convert -delay 100 -loop 5 tkn*.png tkn_%02.gif