#------------------------------------------------------------------------------#
#  Title: Create CFR analysis figure for updownstream manuscript
#   Date: 12/05/2016
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

library(grid)
library(gridExtra)
library(rgdal)
library(dplyr)
library(capefear)
library(maptools)
library(maps)
library(GISTools)
library(rgeos)
library(raster)
library(gridGraphics)



p <-   prep_data_plot(cfrresults ,
                      .scheme    = 'A',
                      # .subscheme = 'b',
                      .interval  = 'I7',
                      .A_quant   = .5,
                      .N_L3_var  = 'p',
                      .P_L3_var  = 'nh3') %>%
  plot_results()

p
#------------------------------------------------------------------------------#
# Map for manuscript plot ####
#------------------------------------------------------------------------------#

### Manuscript Plot ####
# Hydro and trans data downloaded from: https://gdg.sc.egov.usda.gov

# rivers <- readOGR(dsn = "map_data/ncrivers", layer = "ncrivers")
towns  <- readOGR(dsn = "inst/extdata/map_data/twnshps",  layer = "twnshps")
hydro  <- readOGR(dsn = "inst/extdata/map_data/hydrography_NHD24K_extract_3297128_02",  
                  layer = "nhd24kst_l_extract")
trans  <- readOGR(dsn = "inst/extdata/map_data/transportation_TGRROAD_extract_3297128_03",  
                  layer = "road100k_primary_l_extract")
place <- readOGR(dsn = "inst/extdata/map_data/tl_2016_37_place",  
                 layer = "tl_2016_37_place")
urban <- readOGR(dsn = "inst/extdata/map_data/tl_2016_us_uac10",  
                 layer = "tl_2016_us_uac10")

# rivers <- spTransform(rivers, CRS("+init=epsg:4326"))
towns  <- spTransform(towns, CRS("+init=epsg:4326"))
hydro  <- spTransform(hydro, CRS("+init=epsg:4326"))
urban  <- spTransform(urban, CRS("+init=epsg:4326"))
place  <- spTransform(place, CRS("+init=epsg:4326"))

# head(rivers@data)
# head(towns@data)
# head(hydro@data)
# head(place@data)


Hoffer <- filter(sites, cormp_id == 'B7500000')
LD1    <- filter(sites, cormp_id == 'B8349000')
cfr_sites <- filter(sites, cormp_id %in% 
                      c(unique(c(cfr_results$s2_site)), 'B8349000') )
cfr_sites <- SpatialPointsDataFrame(coords = as.matrix(cfr_sites[, c('long', 'lat')]),
                                    data = cfr_sites, proj4string = CRS("+init=epsg:4326"))
cfr_bbox <- matrix(c(Hoffer$long - .1, LD1$lat - .02, 
                     LD1$long + .1, Hoffer$lat + .1), nrow = 2,  
                   byrow = FALSE, dimnames = list( c('x', 'y'), c('min', 'max')))

# Clip places to area with cfr_bbox
place_wi_bounds <- crop(place, cfr_bbox)

# Create rectangular area for plotting
bnds <- cbind(x=c(Hoffer$long + .1, LD1$long + .1, LD1$long - .1, Hoffer$long - .1), 
              y=c(Hoffer$lat  + .1, LD1$lat  + .1,  LD1$lat - .1, Hoffer$lat  - .1))
plot_poly <- SpatialPolygons(list(Polygons(list(Polygon(bnds)),"bbox")), proj4string=CRS("+init=epsg:4326")  )

## Rotate objects to plot
rotateProj = function(spobj, angle) {
  # get bounding box as spatial points object
  boxpts = SpatialPoints(t(bbox(spobj)), proj4string = CRS(proj4string(spobj)))
  # convert to lat-long
  boxLL = bbox(spTransform(boxpts, CRS("+init=epsg:4326")))
  # find the centre
  llc = apply(boxLL, 1, mean)
  # construct the proj4 string
  prj = paste0("+proj=omerc +lat_0=", llc[2], " +lonc=", llc[1], " +alpha=", 
               angle, " +gamma=0.0 +k=1.000000 +x_0=0.000 +y_0=0.000 +ellps=WGS84 +units=m ")
  # return as a CRS:
  CRS(prj)
}

# get the proj4 string
plot_Proj <- rotateProj(place_wi_bounds, 55)
# transform
place_wi_bounds_r <- spTransform(place_wi_bounds, plot_Proj)
plot_poly_r       <- spTransform(plot_poly, plot_Proj)

# Create objects to plot

cfr_places  <- gIntersection(place_wi_bounds_r, plot_poly_r)
hydro_r     <- spTransform(hydro, plot_Proj)
cfr_sites_r <- spTransform(cfr_sites, plot_Proj)

cfr_sites_r <- as.data.frame(cfr_sites_r)
cfr_sites_r$distkm <- round(cfr_sites_r$distance/1000)
cfr_sites_r$text_labels <- c('', 'LD3', '', '', '', '',  '', 'LD2', '', '', 'LD1')


small_map <- function(){
    par(mai = c(0, 0, 0, 0), oma = c(0, 0, 0, 0))
    # plot(x = 0, y = 0, xlim = c(-40000, 40000), ylim = c(-1000, 4100), asp = )
    plot(x = bbox(cfr_places)[1, ], y = bbox(cfr_places)[2, ], type = 'n', lty = 0, axes = FALSE)
    lines(hydro_r[grepl('Cape Fear River', hydro_r$GNIS_NAME), ], col = '#1f78b4', lwd = 2)
    
    # Add  locations
    points(x = cfr_sites_r$long.1[1:10], y = cfr_sites_r$lat.1[1:10] + 1000, col = 'red', pch = 6)
    text(cfr_sites_r$distkm[1:10], x = cfr_sites_r$long.1[1:10], y = cfr_sites_r$lat.1[1:10] + 2000, cex = .65, col = 'grey50')
    # points(x = cfr_sites_r$long.1[11], y = cfr_sites_r$lat.1[11], col = 'red', pch = 20, cex = 2)
    rect(xleft   = cfr_sites_r$long.1[11] - 100, 
         ybottom = cfr_sites_r$lat.1[11]  - 500, 
         xright  = cfr_sites_r$long.1[11] + 100, 
         ytop    = cfr_sites_r$lat.1[11]  + 500, 
         col  = 'red',
         border  = 'red')
    text(cfr_sites_r$text_labels, 
         x = cfr_sites_r$long.1[1:10], 
         y = cfr_sites_r$lat.1[1:10] + 3000, 
         cex = .85,
         col = 'grey50')
    
    
    # Add legend
    points(x = 32000, y = -12000, col = 'red', pch = 6)
    text(' - sampling location', x = 38000, y = -12000, cex = .5)
    
    text('Fayetteville', x = -36000, y = -6000, cex = .75)
    arrows(x0 = -41000, y0 = -6000, x1 = -42000, y1 = -6000, length = .05)
    
    text('Wilmington', x = 38000, y = -4000, cex = .75)
    arrows(x0 = 43000, y0 = -4000, x1 = 44000, y1 = - 4000, length = .05)
    
    text('N', x = 27000, y = -12000, cex = .75, srt = 55)
    # arrows(x0 = -30000, y0 = 2200, x1 = -31000, y1 = 2650, length = .05)
    arrows(x0 = 26000, y0 = -11550, x1 = 25000, y1 = -11100, length = .05)
    text('The Middle Cape Fear River', x = 32000, y = -14000, cex = .75)
}

small_map()
#------------------------------------------------------------------------------#
# Manuscript plot ####
#------------------------------------------------------------------------------#

pdf(file = 'manuscripts/figures/cfr_results.pdf', width = 6.5, height = 8)
# Make figure areas
topVp <- viewport(name = 'base', width  = unit(6.5, 'inches' ), height = unit(8, 'inches' ))

main <- viewport(y = 1, name = 'main', width  = unit(6.5, 'inches' ), height = unit(6, 'inches' ),
                 just = 'top', clip = 'off')

map <- viewport(x = .52, y = 0.0, name = 'map', width  = unit(6.5, 'inches' ), height = unit(3.5, 'inches' ),
                just = 'bottom', clip = 'off')

splot <- vpTree(topVp, vpList(main, map))
pushViewport(splot)
## Print analysis graphics
seekViewport('main')
print(p, newpage = FALSE)

seekViewport('map')
# grid.rect(gp=gpar(lty="dashed"))
grid.echo(small_map, newpage = FALSE)
dev.off()
