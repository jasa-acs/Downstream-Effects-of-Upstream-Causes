#------------------------------------------------------------------------------#
#   Title: Create plots and summaries of CFR analysis for updownstream manuscript
#    Date: 12/14/2016
#  Author: Bradley Saul
# Purpose: Create a volcano plot for all the different analysis setups (cutpoints, ...)
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
# Generate a plot for each combination of L3_var, A_cutpoint, Scheme ####
# no don't this several thousands plots
#------------------------------------------------------------------------------#

volcano_data <- cfrresults %>%
  filter_(~ method != 'gee') %>%
  filter_(~ !failed) %>%
  mutate(distr_label = ifelse(distr == 'N', 'N(0, 1)', 't(0, 1, df == m)'),
       sigma  = factor(var_correction, 
                       levels = c('', 'bc_3', 'bc_2', 'bc_1'),
                       labels = c('hat(Sigma)', 'hat(Sigma)^bc*(b == 0.1)', 
                                  'hat(Sigma)^bc*(b == 0.3)', 'hat(Sigma)^bc*(b == 0.75)'), 
                       ordered = TRUE))

nmethods  <- length(unique(volcano_data$method))
labels <- volcano_data %>%
  distinct(distr_label, sigma, interval_id) %>%
  mutate(x = -8, y = 13)

# volcano_data %>%
#   filter(interval_id == 'I7', pval < 0.01) %>%
#   dplyr::select(A_var, L3_var, distance, A_quantile, method, estimate, scheme_name,
#                 conf.low, conf.high)
#   
  
p <- ggplot(data = volcano_data, aes(x = estimate, y = -log10(pval), color = method)) +
  geom_hline(yintercept = 1, color = 'grey50', linetype = 'dotted') +
  
  # geom_rect(data = data_frame(IntervalID = 'I7'), 
  #           aes(ymin = -log10(0.01), ymax = -log10(0.00001),
  #               xmin = .5, xmax = 5), inherit.aes = FALSE,
  #           alpha = .2) + 
  geom_point(size = .5, shape = 1) +
  geom_text(data = labels, aes(x = x, y = y, color = NULL, label = interval_id),
            color = 'grey85', size = 6) +
  
  ## Scales ##
  scale_x_continuous('Estimate', limits = c(-10, 10)) + 

  scale_color_manual(name = '', 
                     values = c('snm' = "#4553c2", 
                                'gfm' = "#338821", 
                                'msm' = "#af1680", "#04451b"),
                     labels = c('GFM', 'MSM', 'SNM'),
                     guide = guide_legend(
                       label.position = 'top',
                       override.aes = list(shape = 16, 
                                           size = 1,
                                           linetype = rep("blank", nmethods)))) +
  
  annotate(geom = 'text', label = 'alpha == 0.1', parse = TRUE,
           x = -8, y = 1.4, size = 2) + 
  facet_grid(sigma ~ distr_label, labeller = label_parsed) +
  
  ## Annotations
  # geom_rect(
  #   data = data_frame(sigma = 'Sigma^bc*(b == 0.3)', distr_label = 't(0, 1, df == m)'),
  #   aes(xmin = 0, xmax = 5, ymin = 2, ymax = 5),
  #   alpha = .2, 
  #   inherit.aes = FALSE
  # ) +
  # geom_text(
  #   data = data_frame(sigma = 'Sigma^bc*(b == 0.3)', distr_label = 't(0, 1, df == m)'),
  #   aes(x = .5, y = 5, label = "Effects with p < .01"),
  #   size = 3,
  #   color = 'grey50',
  #   inherit.aes = FALSE
  # ) + 
  # facet_wrap(~ interval_id, ncol = 2, nrow = 4, dir = 'v') + 
  theme_classic() +
  theme(
        strip.background = element_blank(), #element_rect(color = 'white'),
        strip.text.y     = element_text(angle = 0, hjust = 0, color = 'grey50'),
        # strip.text       = element_blank(),
        strip.text       = element_text(hjust = .5, color = 'grey50'),
        axis.text        = element_text(size = 6, color = 'grey50'),
        axis.title       = element_text(size = 8),
        axis.title.y     = element_text(angle = 0, vjust = 1, color = 'grey50'),
        axis.title.x     = element_text(hjust = .50, color = 'grey50'),
        axis.ticks       = element_line(color = 'grey50'),
        legend.position    = c(.4,  .9),
        legend.background  = element_rect(fill = NA),
        legend.direction   = 'vertical',
        legend.text        = element_text(size = 8),
        panel.margin     = unit(.25, 'lines'),
        panel.background = element_rect(colour="black"),
        panel.grid.major.x = element_line(color = 'grey95'),
        panel.grid.major.y = element_line(color = 'grey95'))
p

ggsave(p, file = 'manuscripts/figures/cfr_volcano.pdf', width = 6, height = 7)
