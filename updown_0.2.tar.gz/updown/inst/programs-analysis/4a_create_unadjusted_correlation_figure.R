#------------------------------------------------------------------------------#
#  Title: Create CFR analysis figure for updownstream manuscript
#   Date: 12/05/2016
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

library(capefear)
library(ggplot2)

prelim <- cfwq_main %>%
  #### Inclusion / Exclusion ####
  # Include records from May thru September
  filter(month %in% c("Jun", "Jul", "Aug", "Sep")) %>%
  # Include sites with chlorophyll data
  # AND initally include the two sites upstream of B829000 in order to get values for
  # lagged covariates these will be dropped later.
  # filter(has_any_chlorophyll_site == 1 | cormp_id %in% c('B7480000', 'B7500000')) %>%
  
  # Exclude 2013 and prior to 1998
  filter(year < 2013 & year > 1998) %>%
  
  # Exclude sites more than 145km upstream or any distance downstream of LD1
  filter(abs(distance) < 135000, distance >= 0) %>%
  select_(~year, ~month, ~cormp_id, ~distance, ~p, ~no3, ~nh3, ~tkn, ~chlorophyll)

cor_data <- prelim %>% 
  select_(~-chlorophyll) %>%
  left_join(filter(prelim, distance == 0) %>% select_(~year, ~month, ~chlorophyll),
            by = c('year', 'month')) %>%
  tidyr::gather(nutrient, val, -year, -month, -cormp_id, -distance, -chlorophyll) %>%
  group_by(nutrient, distance) %>%
  summarise(cor = cor(val, chlorophyll, use = 'complete.obs', method = 'spearman')) %>%
  mutate(distkm   = distance/1000,
         is_max_cor =  (cor == max(cor)))

xbreaks     <- -unique(cor_data[ , 'distkm'])
xlabels     <- -round(xbreaks, 0)
# Clean up overcrowded x-axis
xlabels[xlabels == 55] <- '55  '
xlabels[xlabels == 49] <- '  49'
# xlabels[xlabels ==  0] <- 'LD1   '

peak_cor <- cor_data %>% filter(is_max_cor)

p <- ggplot(
  data = cor_data, 
  aes(x = -distkm, y = cor, 
      shape    = nutrient,
      group    = nutrient, 
      color    = nutrient,
      linetype = nutrient)) + 
  geom_line(size = .2) + 
  geom_point(aes(size = is_max_cor)) + 
  geom_hline(yintercept = 0, color = 'grey50') + 
  
  geom_point(
    data = peak_cor,
    aes(x = -distkm, y = cor),
    shape = 1,
    size = 3,
    fill = NA,
    color = "black",
    inherit.aes = FALSE
  ) + 
  
  # Scales #
  scale_size_manual(
    values = c(1.5, 2),
    guide = FALSE
  ) + 

  # scale_shape_manual(
  #   values = c(16, 8),
  #   guide = FALSE
  # ) + 
  scale_shape_discrete(
    name = '',
    labels  = c(expression('NH'[3]), expression('NO'[3]), 'P', 'TKN')) +
  scale_color_brewer(
    name = '',
    palette = 'Dark2',
    labels  = c(expression('NH'[3]), expression('NO'[3]), 'P', 'TKN'),
    guide   = guide_legend(label.position = 'top',
                           label.hjust = 0.5)) + 

  scale_linetype(
    name     = '',
    labels  = c(expression('NH'[3]), expression('NO'[3]), 'P', 'TKN')) + 
  
  ## Axis scales ##
  scale_x_continuous('River km upstream of LD1', breaks = xbreaks, labels = xlabels) + 
  scale_y_continuous(
    name = expression(hat(rho)), 
    breaks = c(-.4,  -.2,  0,  .2, .4),
    minor_breaks = c(-.3, -.1, .1 , .3 )) +
  coord_cartesian(xlim = c(0, -135.000), ylim = c(-.45, .45), expand = TRUE) +
  
  # geom_text(data = data.frame(x = -132, y = -.475), aes(x = x, y = y), 
  #           hjust = 0, vjust = 0, size = 3, color = 'gray50',
  #           label = 'River km upstream of LD1', inherit.aes = FALSE) + 
  
  theme_classic() +    
  theme(axis.text.x  = element_text(size = 8, color = 'grey50'),
        axis.title.x = element_text(vjust = 0, size = 8, color = 'grey50'),
        axis.line.x  = element_line(color = 'grey50'),
        axis.text.y  = element_text(size = 8, color = 'grey50'),
        axis.title.y = element_text(angle = 0, vjust = .5, color = 'grey50'),
        axis.ticks   = element_line(color = 'grey50'),
        legend.position    = c(.15,  .85),
        legend.background  = element_rect(fill = NA),
        legend.direction   = 'horizontal',
        legend.text        = element_text(size = 8, hjust = 1, color = 'grey50'),
        panel.grid.major.x = element_blank(),
        # panel.grid.major.x = element_line(color = "grey75", size = 0.15),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.y = element_line(colour= "grey75", size=0.1),
        panel.grid.minor.y = element_line(colour= "grey85", size=0.1))
p

ggsave(p, file = "manuscripts/figures/cfr_correlations.pdf", height = 2.5, width = 6.5)
