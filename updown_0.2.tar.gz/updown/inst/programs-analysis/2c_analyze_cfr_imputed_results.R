#------------------------------------------------------------------------------#
#   Title: Review results of CFR imputed analysis
#    Date: 12/08/2017
#  Author: Bradley Saul
# Purpose: 
#------------------------------------------------------------------------------#

library(updown)
library(capefear)
library(ggplot2)
library(dplyr)

analysis_date <- "20171205"
input_file <- paste0("inst/programs-analysis/results/", analysis_date, 
                     "_cfr_results_complete_impute.rda")
load(file =  input_file)

## Add imputation number
lapply(seq_along(cfr_results_complex_impute), function(i) {
  cfr_results_complex_impute[[i]]$imputation <<- i
})

## Combine imputations
cfr_results_complex_impute <- bind_rows(cfr_results_complex_impute)

## Average across imputations
cfrresults_impute <- cfr_results_complex_impute %>%
  dplyr::select_(~ -analysisdt, ~ -schema) %>%
  tidyr::unnest() %>%
  dplyr::group_by(A_var, L3_var, A_quantile, 
                  scheme_name, s1, s2, s1_site, s2_site, method, m) %>%
  dplyr::select(-term, -message) %>%
  dplyr::summarise(
    n                = n(),
    std.error        = sqrt(mean(std.error^2)      + var(estimate) + var(estimate)/n),
    std.error_bc_1   = sqrt(mean(std.error_bc_1^2) + var(estimate) + var(estimate)/n),
    std.error_bc_2   = sqrt(mean(std.error_bc_2^2) + var(estimate) + var(estimate)/n),
    std.error_bc_3   = sqrt(mean(std.error_bc_3^2) + var(estimate) + var(estimate)/n),
    estimate         = mean(estimate)
  )  %>%
  tidyr::gather(var_type, std_error_val, -A_var, -L3_var, -A_quantile, -scheme_name,
                -s1, -s2, -s1_site, -s2_site, -method, -estimate, -m) %>%
  mutate_(var_correction = ~ substr(var_type, 11, 99)) %>%
  merge(data_frame(distr = c('N', 't')), all = TRUE) %>%
  left_join(critical_values, by = c('distr', 'm')) %>%
  # Create conf intervals
  mutate_(conf.high      = ~ estimate + critical_value * std_error_val,
          conf.low       = ~ estimate - critical_value * std_error_val,
          interval_id    = ~ as.character(interval_id_fun(distr, var_correction))) %>%
  # Create p-values
  mutate_(pval = ~ ifelse(distr == 'N', pnorm(abs(estimate/std_error_val), lower.tail = FALSE),
                          pt(abs(estimate/std_error_val), df = m, lower.tail = FALSE))) %>%
  
  # Add site information to the data
  dplyr::select(cormp_id = s2_site, everything()) %>%
  left_join(sites %>% dplyr::select(cormp_id, distance, location, comment), 
            by = 'cormp_id') %>%
  
  # Create variables needed for plotting
  mutate_(
    scheme        =~ substr(scheme_name, 8, 8),
    subscheme     =~ substr(scheme_name, 9, 9),
    ## Hardcode x-axis jitter to causal methods ##
    dist_jitter   =~ ifelse(method == 'gee', distance - 1800,
                            ifelse(method == 'msm', distance - 600,
                                   ifelse(method == 'snm', distance - 1200, distance))),
    distkm_jitter =~ dist_jitter/1000,
    distkm        =~ distance/1000,
    significant   =~ (conf.low > 0 | conf.high < 0) * 1,
    failed        =~ is.na(estimate)) 
