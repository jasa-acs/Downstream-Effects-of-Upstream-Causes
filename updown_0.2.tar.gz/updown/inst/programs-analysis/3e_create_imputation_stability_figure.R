#------------------------------------------------------------------------------#
#  Title: Repeat CFR analysis figure using "complex imputation" results
#   Date: 12/08/2017
# Author: Bradley Saul
#
#------------------------------------------------------------------------------#

p <-   prep_data_plot(cfrresults_impute ,
                      .scheme    = 'A',
                      # .subscheme = 'b',
                      .interval  = 'I7',
                      .A_quant   = .5,
                      .N_L3_var  = 'p',
                      .P_L3_var  = 'nh3') %>%
  plot_results()

ggsave(p, file = 'manuscripts/figures/cfr_imputation_stability.pdf', width = 6, height = 7)
