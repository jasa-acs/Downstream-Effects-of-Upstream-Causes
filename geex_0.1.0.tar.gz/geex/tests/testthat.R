library(testthat)
library(geex)
library(MASS)
library(lme4)

test_check("geex")
