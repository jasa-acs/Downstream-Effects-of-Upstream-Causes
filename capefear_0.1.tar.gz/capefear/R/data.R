#------------------------------------------------------------------------------#
#' Cape Fear water quality data
#' 
#' Data set containing all obervations from raw data provided by Nature Conservancy.
#' Includes both QC'ed observations and non QC'ed. 
#' 
#' All programs necessary to import and create this dataset are contained in \code{inst/create_datasets}.
#' 
#'@format A data frame with 109 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{date}}{date of the observation}
#'\item{\code{metameter}}{the value of a metameter such as ph, do, temperature, etc.}
#'\item{\code{metameter.remark}}{any remarks provide in the raw data for this observation/metameter}
#'\item{\code{metameter.lcensor}}{an indicator whether this observation was below detection limits}
#'\item{\code{metameter.rcensor}}{an indicator whether this observation was above detection limits}
#'}
#'
#------------------------------------------------------------------------------#
"cfwq"

#------------------------------------------------------------------------------#
#' QC'ed Cape Fear water quality data
#' 
#' Subset to only include values where \code{qc == 'Yes'}
#' 
#' All programs necessary to import and create this dataset are contained in \code{inst/create_datasets}.
#' 
#'@format A data frame with 86 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{date}}{date of the observation}
#'\item{\code{metameter}}{the value of a metameter such as ph, do, temperature, etc.}
#'\item{\code{metameter.remark}}{any remarks provide in the raw data for this observation/metameter}
#'\item{\code{metameter.lcensor}}{an indicator whether this observation was below detection limits}
#'\item{\code{metameter.rcensor}}{an indicator whether this observation was above detection limits}
#'}
#'
#------------------------------------------------------------------------------#
"cfwq_qc"


#------------------------------------------------------------------------------#
#' Cape Fear water quality data for manuscript analysis
#' 
#' Subset to only include values where \code{qc == 'Yes'} and observations from 
#' those sites in the main stem of the Cape Fear River upstream of LD1 to Fayetteville.
#' 
#'@format A data frame with 86 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{date}}{date of the observation}
#'\item{\code{metameter}}{the value of a metameter such as ph, do, temperature, etc.}
#'\item{\code{metameter.remark}}{any remarks provide in the raw data for this observation/metameter}
#'\item{\code{metameter.lcensor}}{an indicator whether this observation was below detection limits}
#'\item{\code{metameter.rcensor}}{an indicator whether this observation was above detection limits}
#'}
#'
#------------------------------------------------------------------------------#
"cfwq_main"

#------------------------------------------------------------------------------#
#' Cape Fear water quality data during summer
#' 
#' Subset to only include values where \code{qc == 'Yes'} and observations from 
#' those sites in the main stem of the Cape Fear River upstream of LD1 to Fayetteville.
#' 
#' Subset to observations from summer only.
#' 
#' All programs necessary to import and create this dataset are contained in \code{inst/create_datasets}.
#'
#'@format A data frame with 86 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{date}}{date of the observation}
#'\item{\code{metameter}}{the value of a metameter such as ph, do, temperature, etc.}
#'\item{\code{metameter.remark}}{any remarks provide in the raw data for this observation/metameter}
#'\item{\code{metameter.lcensor}}{an indicator whether this observation was below detection limits}
#'\item{\code{metameter.rcensor}}{an indicator whether this observation was above detection limits}
#'}
#'
#------------------------------------------------------------------------------#
"cfwq_main_summer"

#------------------------------------------------------------------------------#
#' Details on Cape Fear basin sampling locations
#' 
#' Data set containing details on all sampling locations within the Cape Fear basin.
#' 
#' All programs necessary to import and create this dataset are contained in \code{inst/create_datasets}.
#' 
#'@format A data frame with 17 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{lat}}{latitude of the location}
#'\item{\code{long}}{longitude of the location}
#'\item{\code{huc}}{hydrological unit code}
#'\item{\code{is_main}}{an indicator of whether this location is included in the analysis data}
#'\item{\code{flow_order}}{order of the sites used in the analysis from upstream to downstream}
#'\item{\code{distance}}{distance from Lock and Dam 1 in river kilometers}
#'}
#'
#------------------------------------------------------------------------------#
"sites"

#------------------------------------------------------------------------------#
#' Daily data from USGS stream gauges
#' 
#' Observations for sites between USGS gauges at LD1, LD3, and Lillington are linearly
#' interpolated based on their locations between their upstream and downstream gauges. 
#' Values for LD1 and LD3 locations are actual values obtained from USGS.
#' 
#' All programs necessary to import and create this dataset are contained in \code{inst/create_datasets}.
#' 
#'@format A data frame with 17 variables including:
#'\describe{
#'\item{\code{cormp_id}}{the ID of the sampling location}
#'\item{\code{date}}{date of the observation}
#'\item{\code{discharge_daymean}}{the mean discharge in m^3/s}
#'\item{\code{discharge_lag#mean}}{the mean discharge of the current day and (# - 1) previous days}
#'\item{\code{discharge_lag#sd}}{the standard deviation of discharge of the current day and (# - 1) previous days}
#'}
#'
#------------------------------------------------------------------------------#
"usgs_daily"