## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
#   TITLE: Create CFWQ Dataset
#  AUTHOR: Bradley Saul
#    DATE: 6/15/15
# PURPOSE: Subset the Primary CFWQ dataset to QCed observations
#
## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##

# ## SUBSETTING OBJECTS #####
lock1 <-  "B8349000"

# Drop mineral concentrations. 
# There is little to no data for post 2009.
minerals <- c("cadmium", "chromium", "cu", "ni", "pb", "zi", "al", "fe", "mn", 
              "hg", "as")
drop <- apply(expand.grid(minerals, c("", ".lcensor", ".rcensor", ".remark")),
              1, paste, collapse='')

site_vars <- c("cormp_id", "lat", "long", "huc",  "flow_order", "distance", 
               "is_main", "county", "location")

cfwq_qc <- cfwq %>% 
  # Keep only QCed values
  filter(qc == "Yes") %>%
  
  # Get rid of mineral variables
  select(one_of(setdiff(names(cfwq), drop))) %>%
  
  # Add information about sites
  inner_join(sites[site_vars], by = 'cormp_id')

cfwq_qc <- cfwq_qc %>%
  # Flag years that have chlorophyll measurements per site
  group_by(cormp_id, year) %>%
  summarise(has_any_chlorophyll_year = (sum(!is.na(chlorophyll)) > 1) * 1) %>%
  inner_join(cfwq_qc, by = c('cormp_id', 'year')) %>% 

  # Flag sites that have chlorophyll measurements
  group_by(cormp_id) %>%
  summarise(has_any_chlorophyll_site = (sum(!is.na(chlorophyll)) > 1) * 1) %>%
  inner_join(cfwq_qc, by = 'cormp_id') %>%
  
  # USGS sites are identified in USGS data by 8 character ID
  mutate(usgs_id = ifelse(is.na(usgs_id), NA, as.character(paste0('0', usgs_id)))) %>%
  
  # make final dataset ungrouped
  ungroup()
  

## Save Files ####
save(cfwq_qc, file= 'data/cfwq_qc.rdata')


rm(cfwq_qc, lock1, minerals, drop, site_vars)


