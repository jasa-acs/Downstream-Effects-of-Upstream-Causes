#------------------------------------------------------------------------------#
#' Libraries necessary for running R scripts that create datasets
#'
#------------------------------------------------------------------------------#

library(dplyr)
library(reshape2)
library(stringr)