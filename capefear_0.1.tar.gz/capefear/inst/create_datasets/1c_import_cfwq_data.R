## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
#     TITLE: Data import of Cape Fear data
#    AUTHOR: Bradley Saul
#      DATE: 1/20/2014 
#   PURPOSE: Import and clean raw data for Cape Fear Water project
#     NOTES: Original data provided as an xlsx file. Exported to csv within Excel.
# CHANGELOG:
## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##

csvfile <- "cfr_wq_data_140120.csv"

## IMPORT NUTRIENT DATA ####
raw <- read.csv(file = paste0("inst/extdata/", csvfile), 
                stringsAsFactors = FALSE)

names(raw) <- c("usgs_id", "cormp_id", "date_time", "qc", "depth", "temp.raw", 
               "ph.raw", "do.raw", "conductivity.raw", "fecal.raw",
               "enterococcus.raw", "turbidity.raw", "residue.raw", 
               "chlorophyll.raw", "nh3.raw", "tkn.raw", "no3.raw", "p.raw", 
               "cadmium.raw", "chromium.raw", "cu.raw", "ni.raw", "pb.raw", 
               "zi.raw", "al.raw", "fe.raw", "mn.raw", "hg.raw", "as.raw", 
               "hardness.raw")

cfwq <- raw

# Dates
cfwq$date_time  <- as.POSIXct(strptime(cfwq$date_time, format="%Y-%m-%d %H:%M:%S", 
                                       tz = "EST"))
cfwq$date       <- as.Date(cfwq$date_time)
cfwq$year_month <- format(cfwq$date_time, "%Y-%m")
cfwq$year       <- format(cfwq$date_time, "%Y")
cfwq$month      <- format(cfwq$date_time, "%B")

# Clean up censored values
strip_remarks <- function(x, name){
 stringr::str_extract(x[, name], "\\(.*")
}

strip_values <- function(x, name){
  suppressWarnings(as.numeric(stringr::str_extract(x[ , name], "\\d.\\d*")))
}

clean_vars <- function(data, varlist){
  for(i in seq_along(varlist)){
    var <- stringr::str_extract(varlist[i], "[^\\.]+")
    data[var] <- strip_values(data, varlist[i])
    data[paste0(var, ".remark") ]  <- strip_remarks(data, varlist[i])
    # Censoring values are based on remark codes in 
    # CapeFear_NPDataLocs_updated with remarks.xlsx
    data[paste0(var, ".lcensor") ] <- as.integer(grepl("(U|K|<)", data[, paste0(var, ".remark")]))
    data[paste0(var, ".rcensor") ] <- as.integer(grepl("(>|L)", data[, paste0(var, ".remark")]))
  }
  return(data)
}

# Which variables to clean?
clean_these <- c("temp.raw", "ph.raw", "do.raw", "conductivity.raw", 
                 "fecal.raw", "enterococcus.raw", "turbidity.raw", "residue.raw", 
                 "chlorophyll.raw", "nh3.raw", "tkn.raw", "no3.raw", "p.raw", 
                 "cadmium.raw", "chromium.raw", "cu.raw", "ni.raw", "pb.raw", 
                 "zi.raw", "al.raw", "fe.raw", "mn.raw", "hg.raw", "as.raw", 
                 "hardness.raw")

#Clean 'em
cfwq <- clean_vars(cfwq, clean_these)

#Remove raw values
cfwq <- cfwq[setdiff(names(cfwq), clean_these)]


# Label months
cfwq$month <- ordered(cfwq$month, 
                          labels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                                     "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"), 
                          levels = c("January", "February", "March", "April", 
                                     "May", "June", "July", "August", 
                                     "September", "October", "November",
                                     "December"))
## SAVE FILE ####

save(cfwq, file = "data/cfwq.rdata")

## CLEAN UP ####
rm(cfwq, csvfile, raw, clean_vars, strip_remarks, strip_values, clean_these)
