## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
#   TITLE: Create Discharge Variables
#  AUTHOR: Bradley Saul
#    DATE: 7/9/15
# PURPOSE: Create lagged mean discharge variables
#
## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##

usgs_daily_wide <- reshape(as.data.frame(usgs_daily), timevar = 'usgs_id',
                           idvar = 'date', drop = 'cormp_id', sep = '_',
                           direction = 'wide')

# Upstream/Downstream distances
# Lillington
d_lll <- filter(cfwq_qc, usgs_id == '02102500')$distance[1]
# L&D3
d_ld3 <- filter(cfwq_qc, usgs_id == '02105500')$distance[1]
# L&D1
d_ld1 <- filter(cfwq_qc, usgs_id == '02105769')$distance[1]

main_stem <- select(cfwq_qc, usgs_id, date, cormp_id, year_month, distance, is_main) %>%
  filter(is_main == 1) 

# Discharge variables for selected USGS sites do not need to be interpolated
main_stem_usgs <- filter(main_stem, usgs_id %in% c('02102500', '02105500', '02105769')) %>%
  left_join(usgs_daily, by = c('usgs_id', 'cormp_id',  'date') ) %>%
  select(-ends_with('daymax'), -ends_with('daymin'), -starts_with('height'))

# Discharge variables for other sites DO need to be interpolated
hold <- filter(main_stem, !usgs_id %in% c('02102500', '02105500', '02105769')) %>%
  left_join(usgs_daily_wide, by = "date")

# Function that fits two lines for each variable: one between Lillington and L&D3 
# another between L&D3 and L&D1. A site's discharge value then depends on whether 
# it is upstream or downstream of L&D3.
discharge <- function(variable_name){
  y_lll <- hold[[paste0(variable_name, '_02102500')]]
  y_ld3 <- hold[[paste0(variable_name, '_02105500')]]
  y_ld1 <- hold[[paste0(variable_name, '_02105769')]]
  dist  <- hold[['distance']]
  # Recall that distance is distance from LD1!
  vals <- ifelse(dist < d_ld3,
    ((y_ld1 - y_ld3)/(d_ld3 - d_ld1)) * (d_ld3 - dist) + y_ld3,
    ((y_ld3 - y_lll)/(d_lll - d_ld3)) * (d_lll - dist) + y_lll  )
  
  # A cheap way to prevent negative values
  hold[variable_name] <<- ifelse(vals < 0, 0, vals) 
}

vars <- c('discharge_daymean'  , 
          'discharge_lag3mean' , 'discharge_lag3sd',
          'discharge_lag7mean' , 'discharge_lag7sd',
          'discharge_lag14mean', 'discharge_lag14sd',
          'discharge_lag28mean', 'discharge_lag28sd',
          'discharge_monthmean', 'discharge_monthsd')

for(var in vars){
  discharge(var)
}

main_stem_notusgs <- select(hold, 
                            -ends_with('02105500'), -ends_with('02105769'),
                            -ends_with('02102500'))


main_discharge <- rbind(main_stem_usgs, main_stem_notusgs) %>%
  arrange(-distance)

### Check: Did the process work? ####
# the discharge_monthmean variable should be two straight lines
# the other lag means should show patterns that depend on the day sampled

temp <- filter(main_discharge, year_month == '2002-08')
plot(-temp$distance, temp$discharge_monthmean)

main_discharge <- main_discharge %>% select(-is_main, -year_month, -distance, -usgs_id)


rm(hold, main_stem, main_stem_notusgs, main_stem_usgs, usgs_daily_wide, temp,
   vars, var, d_ld1, d_lll,  d_ld3, discharge)







