#------------------------------------------------------------------------------#
#     TITLE: Import of Cape Fear CORMP sites
#    AUTHOR: Bradley Saul
#      DATE: 6/15/2015
#   PURPOSE: Import sites of CORMP sampling sites
#     NOTES: 
# CHANGELOG:
#------------------------------------------------------------------------------#

# .main = sites identified by TNC as along the main channel of the CFR
# in the area of the blooms

## IMPORT sites ####
sites        <- read.csv("inst/extdata/station_locations.csv", stringsAsFactors = F,
                         col.names = c('station', 'lat', 'long', 'bnum', 'unum',
                                       'huc', 'location', 'county', 'comment',
                                       'stream_class', 'subbasin', 'active', 
                                       'active1'))

sites.main   <- read.csv("inst/extdata/cape_fear_river_station_locations.csv", 
                     stringsAsFactors = F, 
                     col.names = c('fid', 'station', 'lat', 'long', 'bnum', 
                                   'unum', 'huc', 'location', 'dst_ld_mtr', 
                                   'ord_fr_ld1'))

## Distance and order from Lock and Dam 1
sites.main$flow_order <- abs(sites.main$ord_fr_ld1 - 18)
sites.main$distance   <- sites.main$dst_ld_mtr

sites <- merge(sites, sites.main[c("bnum", "flow_order", "distance")], 
                 by = "bnum", all = T)

# Flag stations in main river channel
sites$is_main <- ifelse(sites$bnum %in% sites.main$bnum, 1, 0)

## Clean up sites data ####

# CORMP_ID seems to be BNUM + 0 except for a couple of points
sites$cormp_id <- paste0(sites$bnum, "0")
sites$cormp_id[sites$cormp_id == "B9050020"] <- "B9050025"
sites$cormp_id[sites$cormp_id == "B8610000"] <- "B8610001"


# Check for duplicates
sum(duplicated(unique(sites$cormp_id)))
#B758400 is duplicated. keeping the 'active one'
sites <- subset(sites, station != 'B7584005/MCFRBA_BC1')

## SAVE FILE ####

save(sites, file = "data/sites.rdata")

## CLEAN UP ####
rm(sites, sites.main)
