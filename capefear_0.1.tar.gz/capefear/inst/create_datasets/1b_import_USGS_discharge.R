#------------------------------------------------------------------------------#
#     TITLE: Data import of Cape Fear usgs Data
#    AUTHOR: Bradley Saul
#      DATE: 6/15/2015
#   PURPOSE: Import USGS usgs data Cape Fear Water project
#     NOTES: 
# To download data go to: 
# http://waterdata.usgs.gov/nwis/dv?referred_module=sw&site_no=02102500 (Lillington)
# http://waterdata.usgs.gov/nwis/dv?referred_module=sw&site_no=02105500 (L&D3)
# http://waterdata.usgs.gov/nwis/dv?referred_module=sw&site_no=02105769 (L&D1)
#
# Get usgs and gage height parameters.
# Download tab-separated file(s) to inst/extdata.
# CHANGELOG:
# 150715 adds data from 02102500
#------------------------------------------------------------------------------#

## Necessary functions #####

lag_fun <- function(x, lag_length, fun){
  # @param data the dataset to use
  # @param lag_length number of days (not including current) to perform fun
  # @param fun function name (e.g. mean, sd)
  fun <- match.fun(fun)
  sapply(1:length(x), FUN = function(end_date){
    # handle initial cases that don't have complete lag_length
    if(end_date - lag_length < 1) {
      start_date <- 1
    } else {
      start_date <- end_date - lag_length
    }
    return(fun(x[start_date:end_date]))
  })
}

## Import usgs Data #####

# CFR at Lillington
usgs_02102500 <- read.csv(file = "inst/extdata/usgs_02102500_19960101_20150709.txt", 
                          stringsAsFactors = F,
                          skip = 31,
                          sep  = '\t')

# CFR near LD3
usgs_02105500 <- read.csv(file = "inst/extdata/usgs_02105500_19960101_20150709.txt", 
                          stringsAsFactors = F,
                          skip = 31,
                          sep  = '\t')

# CFR near LD1
usgs_02105769 <- read.csv(file = "inst/extdata/usgs_02105769_19960101_20150709.txt", 
                               stringsAsFactors = F,
                               skip = 31,
                               sep  = '\t')





# Drop unused variables and rename variables #
usgs_02102500  <- usgs_02102500[-1,-c(1,5,7,9,11,13,15)]
usgs_02105500  <- usgs_02105500[-1,-c(1,5,7,9,11,13,15)]
usgs_02105769  <- usgs_02105769[-1,-c(1,5,7,9,11,13,15)]

nameS <- c("site_no", "date", "discharge_daymax", "discharge_daymin", 
           "discharge_daymean", "height_daymax", "height_daymin", 
           "height_daymean")

names(usgs_02102500) <- nameS
names(usgs_02105500) <- nameS
names(usgs_02105769) <- nameS


# Add Cormp_ID to link back to CFR environmental data
usgs_02102500$cormp_id <- "B6370000"
usgs_02105500$cormp_id <- "B8290000"
usgs_02105769$cormp_id <- "B8349000"

# Put all together 
usgs <- rbind(usgs_02102500, usgs_02105500, usgs_02105769)

# Make variable correct type

usgs[,c(3:8)] <- apply(usgs[,c(3:8)], 2, as.numeric)

## Create Summary Discharge Variables for USGS data ####
usgs_daily <- usgs %>% mutate(
  date       = as.Date(strptime(date, format="%Y-%m-%d")),
  year_month = format(date, "%Y-%m"),
  usgs_id    = site_no,
  
  # Convert to cubic meters per second 
  discharge_daymax  = discharge_daymax * 0.0283168466,
  discharge_daymin  = discharge_daymin * 0.0283168466,
  discharge_daymean = discharge_daymean * 0.0283168466,
  height_daymax     = height_daymax * 0.3048,
  height_daymin     = height_daymin * 0.3048,
  height_daymean    = height_daymean * 0.3048,

  # Compute lagged variables
  discharge_lag3mean = lag_fun(discharge_daymean, 2, fun = mean), 
  discharge_lag3sd   = lag_fun(discharge_daymean, 2, fun = sd),
  
  discharge_lag7mean = lag_fun(discharge_daymean, 6, fun = mean),
  discharge_lag7sd   = lag_fun(discharge_daymean, 6, fun = sd),
  
  discharge_lag14mean = lag_fun(discharge_daymean, 13, fun = mean),
  discharge_lag14sd   = lag_fun(discharge_daymean, 13, fun = sd),
  
  discharge_lag28mean = lag_fun(discharge_daymean, 27, fun = mean),
  discharge_lag28sd   = lag_fun(discharge_daymean, 27, fun = sd)
  ) %>%
  # Summarize by month ##
  group_by(usgs_id, year_month, cormp_id) %>%
  mutate(discharge_monthmean = mean(discharge_daymean, na.rm = T),
         discharge_monthsd   = sd(discharge_daymean, na.rm =T),
         height_monthmean    = mean(height_daymean, na.rm = T)  ) %>%
  ungroup() %>%
  select(-site_no, -year_month)

# Save
save(usgs_daily, file = 'data/usgs_daily.rdata')

# Clean up
rm(usgs_02105769, usgs_02105500, usgs_02102500, nameS, usgs, usgs_daily)
