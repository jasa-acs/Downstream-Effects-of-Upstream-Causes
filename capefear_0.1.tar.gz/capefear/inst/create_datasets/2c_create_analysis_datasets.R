## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
#   TITLE: Create Analysis Datasets
#  AUTHOR: Bradley Saul
#    DATE: 6/15/15
# PURPOSE: Subset the cfwq_qc to observations for manuscript analysis
#
## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##

source('programs/analysis_datasets/2b_create_discharge_variables.R')

summer <- c("May", "Jun", "Jul", "Aug", "Sep", "Oct")


## Subset Locations in Main Stem ####
cfwq_main <- cfwq_qc %>% 
  filter(is_main == 1 & 
         # Exclude certain locations 
                      !(cormp_id %in% c('B6215000', # no data before 2010
                                        "B7610000", # no data after 2003
                                        'B8301000', # no data after 2002
                                        'B8330000'  # no data after 2002
                      ))) %>%
  # Merge Discharge data
  left_join(main_discharge,  by = c('cormp_id', 'date')) %>%
  
  # Flag point sources 
  ## TODO: this should to be updated based on locations NPDES permits
  ## and locations of the sites. Perhaps: flag if location is within 5km 
  ## downstream of permit? For now, I'm flagging the one that I know and
  ## that is relevant to simulations. Also should flag p sources.
  mutate(major_n_point_source = ifelse(cormp_id %in% c('B8305000'), 1, 0))

## Subset main stem locations to summer ####
cfwq_main_summer <- subset(cfwq_main, month %in% summer)

save(cfwq_main, file = 'data/cfwq_main.rdata')
save(cfwq_main_summer, file = 'data/cfwq_main_summer.rdata')

rm(summer, main_discharge)
